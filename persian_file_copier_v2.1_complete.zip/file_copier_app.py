import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import customtkinter as ctk
import threading
import queue
import time
import json
import sys
import psutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
import re
from typing import Dict, List, Optional
from datetime import datetime
import uuid
import hashlib
import base64

# Native drag and drop implementation - more reliable than tkinterdnd2
class NativeDragDrop:
    def __init__(self, widget, callback):
        self.widget = widget
        self.callback = callback
        self.drag_data = None
        
        # Bind events for drag and drop
        self.widget.bind("<Button-1>", self.on_click)
        self.widget.bind("<B1-Motion>", self.on_drag)
        self.widget.bind("<ButtonRelease-1>", self.on_drop)
        
    def on_click(self, event):
        # Start drag operation
        self.drag_data = {"start_x": event.x, "start_y": event.y}
        
    def on_drag(self, event):
        # Handle drag motion
        if self.drag_data:
            # Visual feedback during drag
            self.widget.configure(cursor="hand2")
            
    def on_drop(self, event):
        # Handle drop operation
        if self.drag_data:
            self.widget.configure(cursor="")
            # Check if we have file paths to process
            if hasattr(self.widget, 'selection'):
                selected_items = self.widget.selection()
                if selected_items and self.callback:
                    self.callback(selected_items)
        self.drag_data = None

# Licensing System
class LicenseManager:
    def __init__(self):
        self.license_file = "license.key"
        self.company_key = "PERSIANFILECOPIER2024"
        
    def generate_serial(self, customer_name, customer_email):
        """Generate a unique serial number for a customer"""
        timestamp = str(int(time.time()))
        data = f"{customer_name}{customer_email}{timestamp}{self.company_key}"
        hash_obj = hashlib.sha256(data.encode())
        serial = base64.b64encode(hash_obj.digest()).decode()[:20].upper()
        return f"PFC-{serial[:4]}-{serial[4:8]}-{serial[8:12]}-{serial[12:16]}"
    
    def validate_serial(self, serial, customer_name="", customer_email=""):
        """Validate a serial number"""
        try:
            if not serial.startswith("PFC-"):
                return False
            # For demo purposes, accept any properly formatted serial
            parts = serial.split("-")
            return len(parts) == 5 and len(parts[0]) == 3
        except:
            return False
    
    def save_license(self, serial, customer_info):
        """Save license information"""
        license_data = {
            "serial": serial,
            "customer": customer_info,
            "activated": datetime.now().isoformat(),
            "status": "active"
        }
        try:
            with open(self.license_file, "w", encoding="utf-8") as f:
                json.dump(license_data, f, indent=4, ensure_ascii=False)
            return True
        except:
            return False
    
    def load_license(self):
        """Load license information"""
        try:
            with open(self.license_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return None
    
    def is_licensed(self):
        """Check if application is properly licensed"""
        license_data = self.load_license()
        if not license_data:
            return False
        return self.validate_serial(license_data.get("serial", ""))
    
    def is_trial_mode(self):
        """Check if application is in trial mode"""
        license_data = self.load_license()
        if not license_data:
            return True
        return license_data.get("serial", "") == "TRIAL-MODE"
    
    def get_license_type(self):
        """Get the license type (trial, standard, pro)"""
        license_data = self.load_license()
        if not license_data:
            return "trial"
        
        serial = license_data.get("serial", "")
        if serial == "TRIAL-MODE":
            return "trial"
        elif self.validate_serial(serial):
            return license_data.get("license_type", "standard")
        return "trial"

# Enhanced theme configurations - lighter and more colorful
THEMES = {
    "dark_blue": {"mode": "dark", "color": "blue"},
    "dark_green": {"mode": "dark", "color": "green"},
    "light_blue": {"mode": "light", "color": "blue"},
    "light_green": {"mode": "light", "color": "green"},
    "cyberpunk": {"mode": "light", "color": "blue"},  # Changed to light
    "sunset": {"mode": "light", "color": "green"},    # Changed to light
    "ocean": {"mode": "light", "color": "blue"},
    "forest": {"mode": "light", "color": "green"},    # Changed to light
    "system": {"mode": "system", "color": "blue"}
}

# Set initial appearance - lighter theme
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

class FileCopierApp:
    def __init__(self, root):
        self.root = root
        self.root.title("مدیریت فایل ایرانی پیشرفته - Persian File Copier Pro v2.0")
        self.root.geometry("1400x900")
        self.root.minsize(1200, 800)
        
        # Initialize license manager
        self.license_manager = LicenseManager()
        
        # Set application icon
        self.setup_app_icon()
        
        # Initialize variables
        self.copy_tasks = []
        self.task_queue = queue.Queue()
        self.executor = None
        self.is_copying = False
        self.clipboard_files = []
        self.current_dir = os.getcwd()
        self.settings = self.load_settings()
        self.file_cache = self.load_cache()
        self.all_drives = []
        self.destination_folders = []
        self.native_drag_drop = None
        
        # Setup components
        self.setup_logging()
        self.setup_executor()
        self.setup_gui()
        self.setup_bindings()
        
        # Start auto-cleanup of completed tasks
        self.start_auto_cleanup()
        
        # Check license on startup
        self.check_license_on_startup()
        
        # Start comprehensive system scan in background after GUI is ready
        self.update_status("Scanning system drives and files...")
        threading.Thread(target=self.initial_system_scan, daemon=True).start()

    # New callback methods for enhanced functionality
    def on_file_drag_drop(self, selected_items):
        """Handle drag and drop operations on file tree"""
        if selected_items:
            self.copy_selected_files()

    def copy_selected_files(self):
        """Copy selected files from the file tree"""
        selected_items = self.file_tree.selection()
        if not selected_items:
            messagebox.showwarning("هشدار", "لطفاً فایل‌هایی را برای کپی انتخاب کنید")
            return
        
        # Check if bulk copy is allowed (more than 5 files)
        if len(selected_items) > 5:
            if not self.enforce_license_restriction("bulk_copy"):
                return
        
        destination = self.destination_var.get()
        if not destination or destination == "انتخاب مقصد...":
            messagebox.showwarning("هشدار", "لطفاً مقصد کپی را انتخاب کنید")
            return
        
        # Add to copy queue
        for item in selected_items:
            item_values = self.file_tree.item(item, 'values')
            if len(item_values) >= 2:
                file_path = item_values[1]  # Path column
                self.add_copy_task(file_path, destination)

    def select_destination(self):
        """Select destination folder"""
        folder = filedialog.askdirectory(title="انتخاب پوشه مقصد")
        if folder:
            self.destination_var.set(folder)
            # Update combo box values
            current_values = list(self.destination_combo.cget("values"))
            if folder not in current_values:
                current_values.append(folder)
                self.destination_combo.configure(values=current_values)

    def quick_copy_to_folder(self, folder_name):
        """Quick copy to common folders"""
        try:
            # Get user home directory
            home_dir = Path.home()
            
            # Map folder names to actual paths
            folder_map = {
                "Desktop": home_dir / "Desktop",
                "Documents": home_dir / "Documents",
                "Downloads": home_dir / "Downloads", 
                "Pictures": home_dir / "Pictures",
                "Music": home_dir / "Music",
                "Videos": home_dir / "Videos"
            }
            
            destination = folder_map.get(folder_name)
            if destination and destination.exists():
                self.destination_var.set(str(destination))
                self.copy_selected_files()
            else:
                messagebox.showerror("خطا", f"پوشه {folder_name} یافت نشد")
        except Exception as e:
            messagebox.showerror("خطا", f"خطا در کپی سریع: {e}")

    def add_copy_task(self, source, destination):
        """Add a copy task to the queue"""
        task = {
            "id": str(uuid.uuid4()),
            "source": source,
            "destination": destination,
            "status": "pending",
            "progress": 0,
            "created": datetime.now()
        }
        self.copy_tasks.append(task)
        self.update_recent_operations(f"کپی {os.path.basename(source)}", "در صف")
        self.update_status(f"تسک کپی اضافه شد: {os.path.basename(source)}")

    def update_recent_operations(self, operation, status):
        """Update recent operations list"""
        current_time = datetime.now().strftime("%H:%M")
        self.recent_tree.insert("", 0, values=(current_time, operation, status))
        
        # Keep only last 50 operations
        children = self.recent_tree.get_children()
        if len(children) > 50:
            self.recent_tree.delete(children[-1])

    def contact_support(self):
        """Open support contact information"""
        support_info = """
🛠️ راه‌های تماس با پشتیبانی:

📞 تلفن: +98 21 1234 5678
📧 ایمیل: support@persianfile.ir
📱 تلگرام: @PersianFileSupport
🌐 وب‌سایت: www.persianfile.ir

⏰ ساعات کاری: شنبه تا چهارشنبه، 8 تا 17
        """
        messagebox.showinfo("تماس با پشتیبانی", support_info)

    def check_updates(self):
        """Check for software updates"""
        messagebox.showinfo("بروزرسانی", "شما از آخرین نسخه نرم‌افزار استفاده می‌کنید.\n\nنسخه فعلی: 2.0")

    def select_folder(self):
        """Select a folder using file dialog"""
        folder = filedialog.askdirectory(title="انتخاب پوشه")
        if folder:
            # Add folder contents to file tree
            self.scan_and_add_folder_contents(folder)

    def setup_app_icon(self):
        """Setup application icon"""
        try:
            # Create a simple icon using tkinter
            icon_path = "app_icon.ico"
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
            else:
                # Fallback to text icon
                self.root.iconname("📁 Persian File Copier Pro")
        except Exception as e:
            print(f"Could not set application icon: {e}")

    def check_license_on_startup(self):
        """Check license status on application startup"""
        if not self.license_manager.is_licensed():
            self.show_license_dialog()

    def show_license_dialog(self):
        """Show license activation dialog"""
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("فعال‌سازی نرم‌افزار - License Activation")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (dialog.winfo_screenheight() // 2) - (400 // 2)
        dialog.geometry(f"500x400+{x}+{y}")
        
        frame = ctk.CTkFrame(dialog)
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(frame, text="🔑 فعال‌سازی نرم‌افزار", 
                    font=ctk.CTkFont(family="B Nazanin", size=20, weight="bold")).pack(pady=20)
        
        ctk.CTkLabel(frame, text="برای استفاده از نرم‌افزار، لطفاً سریال نامبر خود را وارد کنید:",
                    font=ctk.CTkFont(family="B Nazanin", size=12)).pack(pady=10)
        
        serial_entry = ctk.CTkEntry(frame, width=300, placeholder_text="PFC-XXXX-XXXX-XXXX-XXXX")
        serial_entry.pack(pady=10)
        
        def activate_license():
            serial = serial_entry.get().strip().upper()
            if self.license_manager.validate_serial(serial):
                customer_info = {"name": "User", "email": "user@example.com"}
                if self.license_manager.save_license(serial, customer_info):
                    messagebox.showinfo("موفقیت", "نرم‌افزار با موفقیت فعال شد!")
                    dialog.destroy()
                else:
                    messagebox.showerror("خطا", "خطا در ذخیره اطلاعات لایسنس")
            else:
                messagebox.showerror("خطا", "سریال نامبر نامعتبر است")
        
        ctk.CTkButton(frame, text="فعال‌سازی", command=activate_license).pack(pady=20)
        
        def skip_trial():
            # Allow 30-day trial
            trial_info = {"trial_start": datetime.now().isoformat(), "days_left": 30}
            self.license_manager.save_license("TRIAL-MODE", trial_info)
            dialog.destroy()
        
        ctk.CTkButton(frame, text="استفاده آزمایشی 30 روزه", 
                     command=skip_trial, fg_color="orange").pack(pady=5)

    def check_feature_license(self, feature_name):
        """Check if a feature is available with current license"""
        license_type = self.license_manager.get_license_type()
        
        # Features that require a valid license (not trial)
        premium_features = [
            "bulk_copy",           # Bulk file operations
            "advanced_settings",   # Advanced performance settings  
            "network_drives",      # Network drive access
            "scheduled_tasks",     # Task scheduling
            "batch_processing",    # Batch file processing
            "export_reports"       # Export operation reports
        ]
        
        if feature_name in premium_features:
            return license_type != "trial"
        
        return True  # Basic features are always available
    
    def show_license_restriction_message(self, feature_name):
        """Show message about license restriction"""
        messagebox.showwarning(
            "قابلیت محدود شده", 
            f"این قابلیت ({feature_name}) فقط در نسخه لایسنس شده موجود است.\n"
            "برای فعال‌سازی نرم‌افزار، لطفاً سریال نامبر معتبر وارد کنید.\n\n"
            "برای خرید لایسنس با ما تماس بگیرید:\n"
            "info@persianfile.ir"
        )
    
    def enforce_license_restriction(self, feature_name):
        """Enforce license restriction for a feature"""
        if not self.check_feature_license(feature_name):
            self.show_license_restriction_message(feature_name)
            return False
        return True
    
    def show_license_prompt_for_advanced_settings(self, value=None):
        """Show license prompt when trying to use advanced settings"""
        self.show_license_restriction_message("advanced_settings")

    def setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            filename="copy_log.txt",
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            encoding="utf-8"
        )
        self.logger = logging.getLogger(__name__)

    def setup_executor(self):
        """Initialize thread pool executor with optimized settings"""
        # Calculate optimal number of threads based on CPU cores
        import os
        cpu_count = os.cpu_count() or 4
        optimal_threads = min(max(cpu_count, 2), 8)  # Between 2 and 8 threads
        
        max_workers = self.settings.get("max_threads", optimal_threads)
        self.executor = ThreadPoolExecutor(max_workers=max_workers)

    def load_settings(self) -> Dict:
        """Load application settings from file"""
        default_settings = {
            "theme": "light_blue",
            "buffer_size": 64 * 1024,  # 64KB default
            "max_threads": 4,
            "overwrite_policy": "prompt",
            "window_geometry": "1100x700",
            "verify_copy": True,
            "show_hidden_files": False,
            "auto_retry": True,
            "retry_count": 3,
            "progress_update_interval": 0.5,
            "use_compression": False,
            "preserve_permissions": True,
            "create_backup": False,
            "notification_sound": True,
            "minimize_to_tray": False,
            "auto_clear_completed": False,
            "show_speed_graph": True,
            "language": "en"
        }
        
        try:
            with open("settings.json", "r", encoding="utf-8") as f:
                settings = json.load(f)
                # Merge with defaults
                for key, value in default_settings.items():
                    if key not in settings:
                        settings[key] = value
                return settings
        except (FileNotFoundError, json.JSONDecodeError):
            return default_settings

    def save_settings(self):
        """Save current settings to file"""
        try:
            self.settings["window_geometry"] = self.root.geometry()
            with open("settings.json", "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.logger.error(f"Failed to save settings: {e}")

    def load_cache(self) -> Dict:
        """Load file cache from disk"""
        try:
            with open("file_cache.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"files": {}, "last_scan": 0}

    def save_cache(self):
        """Save file cache to disk"""
        try:
            with open("file_cache.json", "w", encoding="utf-8") as f:
                json.dump(self.file_cache, f, indent=4, ensure_ascii=False)
        except Exception as e:
            self.logger.error(f"Failed to save cache: {e}")

    def initial_system_scan(self):
        """Comprehensive system scan for drives and files at startup"""
        try:
            print("🔍 Starting comprehensive system scan...")
            
            # 1. Scan all available drives and mount points
            self.scan_all_drives()
            
            # 2. Scan files from all drives
            self.scan_all_files()
            
            # 3. Auto-detect destination folders
            self.auto_detect_destinations()
            
            # 4. Update GUI
            self.root.after(0, self.on_scan_complete)
            
        except Exception as e:
            self.logger.error(f"Error in system scan: {e}")
            print(f"❌ System scan error: {e}")
            self.root.after(0, lambda: self.update_status("Scan error - using fallback"))

    def scan_all_drives(self):
        """Scan and detect all available drives and mount points"""
        try:
            self.all_drives = []
            
            # Get all disk partitions
            partitions = psutil.disk_partitions()
            
            for partition in partitions:
                try:
                    # Get partition info
                    partition_info = {
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'opts': partition.opts
                    }
                    
                    # Try to get disk usage
                    try:
                        usage = psutil.disk_usage(partition.mountpoint)
                        partition_info.update({
                            'total': usage.total,
                            'used': usage.used,
                            'free': usage.free,
                            'accessible': True
                        })
                    except (PermissionError, OSError):
                        partition_info.update({
                            'total': 0,
                            'used': 0,
                            'free': 0,
                            'accessible': False
                        })
                    
                    self.all_drives.append(partition_info)
                    print(f"✓ Found drive: {partition.device} -> {partition.mountpoint}")
                    
                except Exception as e:
                    print(f"⚠ Could not access partition {partition.device}: {e}")
                    continue
            
            print(f"✓ Total drives found: {len(self.all_drives)}")
            
        except Exception as e:
            print(f"❌ Error scanning drives: {e}")
            self.logger.error(f"Drive scan error: {e}")

    def scan_all_files(self):
        """Scan files from all accessible drives"""
        try:
            print("📁 Scanning files from all drives...")
            all_files = {}
            total_files = 0
            
            for drive in self.all_drives:
                if not drive['accessible']:
                    continue
                    
                mountpoint = drive['mountpoint']
                print(f"🔍 Scanning {mountpoint}...")
                
                try:
                    # Scan drive with depth limit for performance
                    drive_files = self.scan_directory_recursive(mountpoint, max_depth=3)
                    all_files.update(drive_files)
                    drive_file_count = len(drive_files)
                    total_files += drive_file_count
                    print(f"✓ {mountpoint}: {drive_file_count} files")
                    
                except Exception as e:
                    print(f"⚠ Could not scan {mountpoint}: {e}")
                    continue
            
            # Update cache with all files
            self.file_cache["files"] = all_files
            self.file_cache["last_scan"] = time.time()
            self.file_cache["total_files"] = total_files
            self.save_cache()
            
            print(f"✓ Total files scanned: {total_files}")
            
        except Exception as e:
            print(f"❌ Error scanning files: {e}")
            self.logger.error(f"File scan error: {e}")

    def scan_directory_recursive(self, directory, max_depth=3, current_depth=0):
        """Recursively scan directory with depth limit"""
        files_dict = {}
        
        if current_depth >= max_depth:
            return files_dict
            
        try:
            for item in os.listdir(directory):
                if item.startswith('.'):  # Skip hidden files/folders
                    continue
                    
                item_path = os.path.join(directory, item)
                
                try:
                    if os.path.isfile(item_path):
                        size = self.get_file_size(item_path)
                        files_dict[item_path] = {
                            "name": item,
                            "type": "File",
                            "size": self.format_size(size),
                            "raw_size": size,
                            "drive": directory.split(os.sep)[0] if os.sep in directory else directory
                        }
                    elif os.path.isdir(item_path) and current_depth < max_depth - 1:
                        # Recursively scan subdirectories
                        sub_files = self.scan_directory_recursive(item_path, max_depth, current_depth + 1)
                        files_dict.update(sub_files)
                        
                        # Also add the directory itself
                        files_dict[item_path] = {
                            "name": item,
                            "type": "Directory",
                            "size": "",
                            "raw_size": 0,
                            "drive": directory.split(os.sep)[0] if os.sep in directory else directory
                        }
                        
                except (OSError, PermissionError):
                    continue
                    
        except (OSError, PermissionError):
            pass
            
        return files_dict

    def auto_detect_destinations(self):
        """Automatically detect and set up destination folders from all drives"""
        try:
            self.destination_folders = []
            
            # Add all accessible drive root directories as destinations
            for drive in self.all_drives:
                if drive['accessible'] and drive['free'] > 0:
                    dest_info = {
                        'path': drive['mountpoint'],
                        'name': f"{drive['device']} ({self.format_size(drive['free'])} free)",
                        'type': 'drive',
                        'free_space': drive['free'],
                        'total_space': drive['total']
                    }
                    self.destination_folders.append(dest_info)
            
            # Add common user directories if they exist
            common_dirs = [
                ('Desktop', os.path.expanduser('~/Desktop')),
                ('Documents', os.path.expanduser('~/Documents')),
                ('Downloads', os.path.expanduser('~/Downloads')),
                ('Pictures', os.path.expanduser('~/Pictures')),
                ('Videos', os.path.expanduser('~/Videos')),
                ('Music', os.path.expanduser('~/Music'))
            ]
            
            for name, path in common_dirs:
                if os.path.exists(path) and os.path.isdir(path):
                    try:
                        usage = psutil.disk_usage(path)
                        dest_info = {
                            'path': path,
                            'name': f"{name} ({self.format_size(usage.free)} free)",
                            'type': 'user_folder',
                            'free_space': usage.free,
                            'total_space': usage.total
                        }
                        # Avoid duplicates
                        if not any(d['path'] == path for d in self.destination_folders):
                            self.destination_folders.append(dest_info)
                    except:
                        continue
            
            print(f"✓ Auto-detected {len(self.destination_folders)} destination folders")
            
        except Exception as e:
            print(f"❌ Error auto-detecting destinations: {e}")
            self.logger.error(f"Destination detection error: {e}")

    def on_scan_complete(self):
        """Called when initial system scan is complete"""
        try:
            # Display cached files
            self.display_cache()
            
            # Update destination folders in GUI
            self.update_destination_folders_display()
            
            # Update drive combo box if it exists
            if hasattr(self, 'drive_combo'):
                self.populate_drive_combo()
            
            # Update status
            total_files = self.file_cache.get("total_files", 0)
            total_drives = len(self.all_drives)
            self.update_status(f"Ready - {total_files} files from {total_drives} drives scanned")
            
            print("✅ System scan completed successfully")
            
        except Exception as e:
            print(f"❌ Error completing scan: {e}")
            self.update_status("Ready - scan completed with errors")

    def populate_drive_combo(self):
        """Populate the drive combo box with available drives"""
        try:
            drive_options = []
            
            for drive in self.all_drives:
                if drive['accessible']:
                    free_space = self.format_size(drive['free'])
                    total_space = self.format_size(drive['total'])
                    drive_label = f"{drive['device']} - {drive['mountpoint']} ({free_space}/{total_space})"
                    drive_options.append(drive_label)
            
            if drive_options:
                self.drive_combo.configure(values=drive_options)
                self.drive_var.set(drive_options[0])
            else:
                self.drive_combo.configure(values=["هیچ درایوی یافت نشد"])
                self.drive_var.set("هیچ درایوی یافت نشد")
                
        except Exception as e:
            print(f"Error populating drive combo: {e}")

    def start_auto_cleanup(self):
        """Start automatic cleanup of completed tasks"""
        def cleanup_completed_tasks():
            try:
                current_time = time.time()
                tasks_to_remove = []
                
                for i, task in enumerate(self.copy_tasks):
                    if task["completed"] and task["status"] == "✅ Completed":
                        # Check if task was completed more than 30 seconds ago
                        completion_time = task.get("completion_time", 0)
                        if completion_time > 0 and (current_time - completion_time) > 30:
                            tasks_to_remove.append(i)
                
                # Remove completed tasks from list and tree
                for i in reversed(tasks_to_remove):
                    task_id = self.copy_tasks[i]["id"]
                    try:
                        self.task_tree.delete(str(task_id))
                    except:
                        pass
                    self.copy_tasks.pop(i)
                
                if tasks_to_remove:
                    print(f"🧹 Cleaned up {len(tasks_to_remove)} completed tasks")
                    self.update_overall_progress()
                    
            except Exception as e:
                print(f"Error in auto cleanup: {e}")
            
            # Schedule next cleanup
            self.root.after(10000, cleanup_completed_tasks)  # Check every 10 seconds
        
        # Start the cleanup cycle
        self.root.after(5000, cleanup_completed_tasks)  # Start after 5 seconds

    def refresh_drives(self):
        """Refresh the drive list in the drive combo box"""
        try:
            self.scan_all_drives()
            drive_options = []
            
            for drive in self.all_drives:
                if drive['accessible']:
                    free_space = self.format_size(drive['free'])
                    total_space = self.format_size(drive['total'])
                    drive_label = f"{drive['device']} - {drive['mountpoint']} ({free_space}/{total_space})"
                    drive_options.append(drive_label)
            
            if drive_options:
                self.drive_combo.configure(values=drive_options)
                if not self.drive_var.get() or self.drive_var.get() == "در حال بارگذاری...":
                    self.drive_var.set(drive_options[0])
            else:
                self.drive_combo.configure(values=["هیچ درایوی یافت نشد"])
                self.drive_var.set("هیچ درایوی یافت نشد")
                
        except Exception as e:
            print(f"Error refreshing drives: {e}")
            self.drive_combo.configure(values=["خطا در بارگذاری درایوها"])
            self.drive_var.set("خطا در بارگذاری درایوها")

    def on_drive_selected(self, selected_drive):
        """Handle drive selection from combo box"""
        try:
            if not selected_drive or selected_drive in ["در حال بارگذاری...", "هیچ درایوی یافت نشد", "خطا در بارگذاری درایوها"]:
                return
                
            # Extract mountpoint from the selected drive string
            # Format is "Device - Mountpoint (free/total)"
            parts = selected_drive.split(" - ")
            if len(parts) >= 2:
                mountpoint_part = parts[1].split(" (")[0]  # Remove the space info part
                
                # Find the drive in our all_drives list
                selected_drive_info = None
                for drive in self.all_drives:
                    if drive['mountpoint'] == mountpoint_part:
                        selected_drive_info = drive
                        break
                
                if selected_drive_info:
                    self.browse_drive(selected_drive_info)
                    
        except Exception as e:
            print(f"Error selecting drive: {e}")

    def browse_drive(self, drive_info):
        """Browse files in the selected drive"""
        try:
            mountpoint = drive_info['mountpoint']
            print(f"Browsing drive: {mountpoint}")
            
            # Clear current file tree
            for item in self.file_tree.get_children():
                self.file_tree.delete(item)
            
            # Scan files in the selected drive
            drive_files = self.scan_directory_recursive(mountpoint, max_depth=2)
            
            # Display files in the tree
            for file_path, file_info in drive_files.items():
                try:
                    name = file_info.get("name", os.path.basename(file_path))
                    file_type = file_info.get("type", "file")
                    size = self.format_size(file_info.get("size", 0))
                    
                    self.file_tree.insert("", "end", values=(name, file_path, file_type, size))
                except Exception as e:
                    print(f"Error adding file to tree: {e}")
                    
            self.update_status(f"تصفح درایو {mountpoint} - {len(drive_files)} فایل یافت شد")
            
        except Exception as e:
            print(f"Error browsing drive: {e}")
            self.update_status(f"خطا در تصفح درایو: {e}")

    def setup_gui(self):
        """Setup the main GUI"""
        # Apply theme
        theme_config = THEMES.get(self.settings["theme"], THEMES["dark_blue"])
        ctk.set_appearance_mode(theme_config["mode"])
        ctk.set_default_color_theme(theme_config["color"])
        
        # Configure window - check if it's CTk or regular Tk
        try:
            if isinstance(self.root, ctk.CTk):
                self.root.configure(fg_color=("#f8f9fa", "gray20"))  # Lighter background
            else:
                # For TkinterDnD.Tk(), use regular tkinter configuration
                self.root.configure(bg='#f8f9fa')
        except Exception as e:
            print(f"Warning: Could not configure root window: {e}")
        
        # Set default font for the entire application
        try:
            # Try to use B Nazanin font
            default_font = ctk.CTkFont(family="B Nazanin", size=12)
            self.default_font = default_font
        except:
            # Fallback to system default if B Nazanin is not available
            default_font = ctk.CTkFont(family="B Nazanin", size=12)
            self.default_font = default_font
            print("B Nazanin font not found, using system default")
        
        # Main container with gradient effect
        self.main_frame = ctk.CTkFrame(
            self.root,
            corner_radius=15,
            fg_color=("#ffffff", "#f0f0f0"),  # Much lighter colors
            border_width=2,
            border_color=("#d0d0d0", "#b0b0b0")
        )
        self.main_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Create notebook for tabs with custom styling
        self.notebook = ttk.Notebook(self.main_frame)
        
        # Configure tab colors with simplified approach
        try:
            style = ttk.Style()
            
            # Try to configure basic styling - use valid color names
            style.configure("TNotebook", 
                          background="#f0f0f0",
                          borderwidth=0)
            style.configure("TNotebook.Tab",
                          padding=[15, 8],
                          font=('B Nazanin', 10, 'bold'))
            
            print("✓ Basic tab styling applied")
        except Exception as e:
            print(f"Could not configure tab styling: {e}")
        
        self.notebook.pack(fill="both", expand=True, pady=(0, 10))
        
        # تب مرورگر فایل با سایدبار کپی سریع - تم آبی روشن
        self.explorer_frame = ctk.CTkFrame(self.notebook, fg_color=("#f3f9ff", "#e3f2fd"))
        self.notebook.add(self.explorer_frame, text="📁 مرورگر فایل و کپی سریع")
        self.setup_explorer_tab()
        
        # تب کارهای کپی - تم سبز روشن
        self.tasks_frame = ctk.CTkFrame(self.notebook, fg_color=("#f1f8e9", "#e8f5e8"))
        self.notebook.add(self.tasks_frame, text="📋 کارهای کپی")
        self.setup_tasks_tab()
        
        # تب تنظیمات - تم نارنجی روشن
        self.settings_frame = ctk.CTkFrame(self.notebook, fg_color=("#fff8e1", "#fff3e0"))
        self.notebook.add(self.settings_frame, text="⚙️ تنظیمات")
        self.setup_settings_tab()
        
        # تب درباره ما - تم بنفش روشن
        self.about_frame = ctk.CTkFrame(self.notebook, fg_color=("#f3e5f5", "#e1bee7"))
        self.notebook.add(self.about_frame, text="ℹ️ درباره ما")
        self.setup_about_tab()
        
        # Tab colors are now implemented through frame colors
        print("✓ Tab colors implemented through frame backgrounds")
        
        # Status bar
        self.setup_status_bar()

    def setup_about_tab(self):
        """Setup the About Us tab with company information"""
        
        # Main container
        main_container = ctk.CTkScrollableFrame(self.about_frame)
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Company logo/header
        header_frame = ctk.CTkFrame(main_container)
        header_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(header_frame, text="🏢 شرکت فناوری پارس فایل", 
                    font=ctk.CTkFont(family="B Nazanin", size=24, weight="bold")).pack(pady=15)
        
        ctk.CTkLabel(header_frame, text="Persian File Technology Company", 
                    font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold")).pack(pady=5)
        
        # Company information
        info_frame = ctk.CTkFrame(main_container)
        info_frame.pack(fill="x", pady=(0, 20))
        
        company_info = [
            ("📍 آدرس:", "تهران، خیابان ولیعصر، پلاک ۱۲۳"),
            ("📞 تلفن:", "+98 21 1234 5678"),
            ("📧 ایمیل:", "info@persianfile.ir"),
            ("🌐 وب‌سایت:", "www.persianfile.ir"),
            ("📱 تلگرام:", "@PersianFileSupport")
        ]
        
        for label, value in company_info:
            info_row = ctk.CTkFrame(info_frame)
            info_row.pack(fill="x", padx=10, pady=5)
            
            ctk.CTkLabel(info_row, text=label, font=ctk.CTkFont(family="B Nazanin", weight="bold"), 
                        anchor="e").pack(side="right", padx=10)
            ctk.CTkLabel(info_row, text=value, font=ctk.CTkFont(family="B Nazanin"), 
                        anchor="w").pack(side="left", padx=10)
        
        # Product information
        product_frame = ctk.CTkFrame(main_container)
        product_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(product_frame, text="📦 درباره محصول", 
                    font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold")).pack(pady=10)
        
        product_text = """
Persian File Copier Pro نرم‌افزاری پیشرفته و قدرتمند برای مدیریت و کپی فایل‌ها است که با هدف تسهیل کار کاربران ایرانی طراحی شده است.

✨ ویژگی‌های کلیدی:
• پشتیبانی کامل از زبان فارسی
• رابط کاربری مدرن و زیبا
• کپی سریع و ایمن فایل‌ها
• پشتیبانی از درگ اند دراپ
• مدیریت پیشرفته صف کپی
• گزارش‌گیری کامل از عملیات

🎯 مناسب برای:
• کاربران خانگی
• شرکت‌ها و سازمان‌ها
• مراکز آموزشی
• کافه‌نت‌ها

💎 نسخه حرفه‌ای با امکانات ویژه برای استفاده تجاری
        """
        
        ctk.CTkLabel(product_frame, text=product_text, 
                    font=ctk.CTkFont(family="B Nazanin", size=12),
                    justify="right", anchor="e").pack(padx=15, pady=10)
        
        # License information
        license_frame = ctk.CTkFrame(main_container)
        license_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(license_frame, text="🔑 اطلاعات لایسنس", 
                    font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold")).pack(pady=10)
        
        # Show current license status
        license_data = self.license_manager.load_license()
        if license_data:
            if license_data.get("serial") == "TRIAL-MODE":
                status_text = "🟡 نسخه آزمایشی (30 روزه)"
            else:
                status_text = f"🟢 فعال - سریال: {license_data.get('serial', 'نامشخص')}"
        else:
            status_text = "🔴 غیرفعال"
        
        ctk.CTkLabel(license_frame, text=f"وضعیت لایسنس: {status_text}", 
                    font=ctk.CTkFont(family="B Nazanin", size=14)).pack(pady=5)
        
        # Support section
        support_frame = ctk.CTkFrame(main_container)
        support_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(support_frame, text="🛠️ پشتیبانی و خدمات", 
                    font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold")).pack(pady=10)
        
        support_buttons = ctk.CTkFrame(support_frame)
        support_buttons.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkButton(support_buttons, text="📞 تماس با پشتیبانی", 
                     font=ctk.CTkFont(family="B Nazanin"),
                     command=self.contact_support).pack(side="right", padx=5)
        
        ctk.CTkButton(support_buttons, text="🔄 بروزرسانی نرم‌افزار", 
                     font=ctk.CTkFont(family="B Nazanin"),
                     command=self.check_updates).pack(side="right", padx=5)
        
        ctk.CTkButton(support_buttons, text="🔑 فعال‌سازی لایسنس", 
                     font=ctk.CTkFont(family="B Nazanin"),
                     command=self.show_license_dialog).pack(side="right", padx=5)
        
        # Copyright
        copyright_frame = ctk.CTkFrame(main_container)
        copyright_frame.pack(fill="x")
        
        ctk.CTkLabel(copyright_frame, text="© 2024 شرکت فناوری پارس فایل - تمامی حقوق محفوظ است", 
                    font=ctk.CTkFont(family="B Nazanin", size=10)).pack(pady=10)

    def refresh_destinations(self):
        """Refresh and re-scan destination folders"""
        self.update_status("Refreshing destinations...")
        threading.Thread(target=self._refresh_destinations_thread, daemon=True).start()
    
    def _refresh_destinations_thread(self):
        """Thread function to refresh destinations"""
        try:
            # Re-scan drives and destinations
            self.scan_all_drives()
            self.auto_detect_destinations()
            
            # Update GUI
            self.root.after(0, self.update_destination_folders_display)
            self.root.after(0, lambda: self.update_status("Destinations refreshed"))
            
        except Exception as e:
            print(f"❌ Error refreshing destinations: {e}")
            self.root.after(0, lambda: self.update_status("Destination refresh error"))

    def setup_explorer_tab(self):
        """Setup the file explorer tab with 3-column layout: File Browser, Copy Operations, Task Management"""
        # Main horizontal layout: file browser (33%), copy operations (33%), task management (33%)
        main_container = ctk.CTkFrame(self.explorer_frame)
        main_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Configure grid weights for 3-column split
        main_container.grid_columnconfigure(0, weight=1)
        main_container.grid_columnconfigure(1, weight=1)
        main_container.grid_columnconfigure(2, weight=1)
        main_container.grid_rowconfigure(0, weight=1)
        
        # Left side: File Browser (33%)
        browser_frame = ctk.CTkFrame(main_container)
        browser_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 3))
        
        # Middle: Copy Operations (33%)
        copy_operations_frame = ctk.CTkFrame(main_container)
        copy_operations_frame.grid(row=0, column=1, sticky="nsew", padx=(3, 3))
        
        # Right side: Task Management (33%)
        task_management_frame = ctk.CTkFrame(main_container)
        task_management_frame.grid(row=0, column=2, sticky="nsew", padx=(3, 0))
        
        # Setup all sections
        self.setup_file_browser_section(browser_frame)
        self.setup_copy_operations_section(copy_operations_frame)
        self.setup_task_management_section(task_management_frame)

    def setup_file_browser_section(self, browser_frame):
        """Setup the file browser section"""
        
        # Title
        title_label = ctk.CTkLabel(browser_frame, text="📁 مرورگر فایل", 
                                  font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold"))
        title_label.pack(pady=(10, 5))
        
        # Drive selection frame
        drive_frame = ctk.CTkFrame(browser_frame)
        drive_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(drive_frame, text="💿 انتخاب درایو:", 
                    font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(side="right", padx=5)
        
        self.drive_var = tk.StringVar()
        self.drive_combo = ctk.CTkComboBox(drive_frame, variable=self.drive_var,
                                         font=ctk.CTkFont(family="B Nazanin"),
                                         values=["در حال بارگذاری..."],
                                         command=self.on_drive_selected)
        self.drive_combo.pack(side="left", fill="x", expand=True, padx=5)
        
        ctk.CTkButton(drive_frame, text="🔄", command=self.refresh_drives,
                     width=30, font=ctk.CTkFont(family="B Nazanin")).pack(side="left", padx=2)
        
        # Search and navigation frame
        nav_frame = ctk.CTkFrame(browser_frame)
        nav_frame.pack(fill="x", padx=10, pady=5)
        
        # Search frame
        search_frame = ctk.CTkFrame(nav_frame)
        search_frame.pack(fill="x", pady=5)
        
        ctk.CTkLabel(search_frame, text="جستجو:", font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(side="right", padx=5)
        self.search_entry = ctk.CTkEntry(search_frame, placeholder_text="نام فایل یا پسوند وارد کنید", 
                                        font=ctk.CTkFont(family="B Nazanin"), justify="right")
        self.search_entry.pack(side="left", fill="x", expand=True, padx=5)
        
        # Buttons frame
        buttons_frame = ctk.CTkFrame(nav_frame)
        buttons_frame.pack(fill="x", pady=5)
        
        ctk.CTkButton(buttons_frame, text="🔄 بروزرسانی", command=self.refresh_all_files, 
                     width=100, font=ctk.CTkFont(family="B Nazanin")).pack(side="left", padx=2)
        ctk.CTkButton(buttons_frame, text="🗑️ پاک کردن", command=self.clear_search, 
                     width=100, font=ctk.CTkFont(family="B Nazanin")).pack(side="left", padx=2)
        
        # File tree with improved styling
        tree_frame = ctk.CTkFrame(browser_frame)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Create treeview with scrollbars
        tree_container = tk.Frame(tree_frame, bg=tree_frame.cget("fg_color")[1])
        tree_container.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.file_tree = ttk.Treeview(
            tree_container,
            columns=("Name", "Path", "Type", "Size"),
            show="headings",
            height=12
        )
        
        # Configure columns - simplified for better fit
        self.file_tree.heading("Name", text="📁 نام فایل")
        self.file_tree.heading("Path", text="📂 مسیر")
        self.file_tree.heading("Type", text="📄 نوع")
        self.file_tree.heading("Size", text="💾 اندازه")
        
        self.file_tree.column("Name", width=150, minwidth=100)
        self.file_tree.column("Path", width=200, minwidth=150)
        self.file_tree.column("Type", width=60, minwidth=50)
        self.file_tree.column("Size", width=80, minwidth=60)
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(tree_container, orient="vertical", command=self.file_tree.yview)
        h_scrollbar = ttk.Scrollbar(tree_container, orient="horizontal", command=self.file_tree.xview)
        
        self.file_tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Grid layout for tree and scrollbars
        self.file_tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        tree_container.grid_rowconfigure(0, weight=1)
        tree_container.grid_columnconfigure(0, weight=1)
        
        # Setup native drag and drop for file tree
        self.native_drag_drop = NativeDragDrop(self.file_tree, self.on_file_drag_drop)
        
        # Action buttons
        action_frame = ctk.CTkFrame(browser_frame)
        action_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkButton(action_frame, text="📋 کپی انتخاب شده", command=self.copy_selected_files,
                     width=120, font=ctk.CTkFont(family="B Nazanin")).pack(side="left", padx=2)
        ctk.CTkButton(action_frame, text="📁 انتخاب پوشه", command=self.select_folder,
                     width=120, font=ctk.CTkFont(family="B Nazanin")).pack(side="left", padx=2)

    def setup_copy_operations_section(self, copy_frame):
        """Setup the copy operations section"""
        
        # Title
        title_label = ctk.CTkLabel(copy_frame, text="⚡ عملیات کپی سریع", 
                                  font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold"))
        title_label.pack(pady=(10, 5))
        
        # Destination selection
        dest_frame = ctk.CTkFrame(copy_frame)
        dest_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(dest_frame, text="📂 مقصد:", 
                    font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(anchor="e", padx=5, pady=2)
        
        self.destination_var = tk.StringVar()
        self.destination_combo = ctk.CTkComboBox(dest_frame, variable=self.destination_var,
                                               font=ctk.CTkFont(family="B Nazanin"),
                                               values=["انتخاب مقصد..."])
        self.destination_combo.pack(fill="x", padx=5, pady=2)
        
        ctk.CTkButton(dest_frame, text="📁 انتخاب پوشه جدید", command=self.select_destination,
                     font=ctk.CTkFont(family="B Nazanin")).pack(fill="x", padx=5, pady=2)
        
        # Quick copy buttons
        quick_frame = ctk.CTkFrame(copy_frame)
        quick_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(quick_frame, text="🚀 کپی سریع:", 
                    font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(anchor="e", padx=5, pady=2)
        
        # Common destinations
        common_destinations = [
            ("🖥️ دسکتاپ", "Desktop"),
            ("📁 اسناد", "Documents"), 
            ("⬇️ دانلودها", "Downloads"),
            ("🖼️ تصاویر", "Pictures"),
            ("🎵 موسیقی", "Music"),
            ("🎬 ویدیوها", "Videos")
        ]
        
        for text, folder in common_destinations:
            ctk.CTkButton(quick_frame, text=text, 
                         command=lambda f=folder: self.quick_copy_to_folder(f),
                         font=ctk.CTkFont(family="B Nazanin"), width=150).pack(fill="x", padx=5, pady=1)
        
        # Copy progress section
        progress_frame = ctk.CTkFrame(copy_frame)
        progress_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(progress_frame, text="📊 وضعیت کپی:", 
                    font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(anchor="e", padx=5, pady=2)
        
        self.copy_progress = ctk.CTkProgressBar(progress_frame)
        self.copy_progress.pack(fill="x", padx=5, pady=2)
        self.copy_progress.set(0)
        
        self.copy_status_label = ctk.CTkLabel(progress_frame, text="آماده برای کپی", 
                                            font=ctk.CTkFont(family="B Nazanin"))
        self.copy_status_label.pack(padx=5, pady=2)
        
        # Recent operations
        recent_frame = ctk.CTkFrame(copy_frame)
        recent_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        ctk.CTkLabel(recent_frame, text="📋 عملیات اخیر:", 
                    font=ctk.CTkFont(family="B Nazanin", weight="bold")).pack(anchor="e", padx=5, pady=2)
        
        # Recent operations list
        recent_container = tk.Frame(recent_frame, bg=recent_frame.cget("fg_color")[1])
        recent_container.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.recent_tree = ttk.Treeview(
            recent_container,
            columns=("Time", "Operation", "Status"),
            show="headings",
            height=8
        )
        
        self.recent_tree.heading("Time", text="⏰ زمان")
        self.recent_tree.heading("Operation", text="📝 عملیات")
        self.recent_tree.heading("Status", text="✅ وضعیت")
        
        self.recent_tree.column("Time", width=80, minwidth=60)
        self.recent_tree.column("Operation", width=150, minwidth=100)
        self.recent_tree.column("Status", width=80, minwidth=60)
        
        recent_scrollbar = ttk.Scrollbar(recent_container, orient="vertical", command=self.recent_tree.yview)
        self.recent_tree.configure(yscrollcommand=recent_scrollbar.set)
        
        self.recent_tree.grid(row=0, column=0, sticky="nsew")
        recent_scrollbar.grid(row=0, column=1, sticky="ns")
        
        recent_container.grid_rowconfigure(0, weight=1)
        recent_container.grid_columnconfigure(0, weight=1)

    def setup_task_management_section(self, task_frame):
        """Setup the task management section in the main explorer tab"""
        
        # Title
        title_label = ctk.CTkLabel(task_frame, text="📋 مدیریت کارها", 
                                  font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold"))
        title_label.pack(pady=(10, 5))
        
        # Control buttons (compact version)
        control_frame = ctk.CTkFrame(task_frame)
        control_frame.pack(fill="x", padx=5, pady=5)
        
        # Main control buttons
        main_controls = ctk.CTkFrame(control_frame)
        main_controls.pack(fill="x", pady=(0, 2))
        
        self.start_btn = ctk.CTkButton(main_controls, text="▶", command=self.start_selected_task,
                                      fg_color="green", hover_color="darkgreen", 
                                      font=ctk.CTkFont(family="B Nazanin"), width=40, height=25)
        self.start_btn.pack(side="left", padx=1)
        
        self.pause_btn = ctk.CTkButton(main_controls, text="⏸", command=self.pause_selected_task,
                                      fg_color="orange", hover_color="darkorange", 
                                      font=ctk.CTkFont(family="B Nazanin"), width=40, height=25)
        self.pause_btn.pack(side="left", padx=1)
        
        self.cancel_btn = ctk.CTkButton(main_controls, text="⏹", command=self.cancel_selected_task,
                                       fg_color="red", hover_color="darkred", 
                                       font=ctk.CTkFont(family="B Nazanin"), width=40, height=25)
        self.cancel_btn.pack(side="left", padx=1)
        
        self.restart_btn = ctk.CTkButton(main_controls, text="🔄", command=self.restart_selected_task,
                                        fg_color="blue", hover_color="darkblue", 
                                        font=ctk.CTkFont(family="B Nazanin"), width=40, height=25)
        self.restart_btn.pack(side="left", padx=1)
        
        # Task management buttons
        task_controls = ctk.CTkFrame(control_frame)
        task_controls.pack(fill="x")
        
        ctk.CTkButton(task_controls, text="🗑", command=self.clear_all_tasks, 
                     font=ctk.CTkFont(family="B Nazanin"), width=40, height=25).pack(side="left", padx=1)
        ctk.CTkButton(task_controls, text="✓", command=self.clear_completed, 
                     font=ctk.CTkFont(family="B Nazanin"), width=40, height=25).pack(side="left", padx=1)
        ctk.CTkButton(task_controls, text="↓", command=self.move_task_down, 
                     font=ctk.CTkFont(family="B Nazanin"), width=40, height=25).pack(side="left", padx=1)
        ctk.CTkButton(task_controls, text="↑", command=self.move_task_up, 
                     font=ctk.CTkFont(family="B Nazanin"), width=40, height=25).pack(side="left", padx=1)
        
        # Progress overview (compact)
        progress_frame = ctk.CTkFrame(task_frame)
        progress_frame.pack(fill="x", padx=5, pady=2)
        
        self.overall_progress = ctk.CTkProgressBar(progress_frame, height=15)
        self.overall_progress.pack(fill="x", padx=5, pady=2)
        self.overall_progress.set(0)
        
        self.progress_label = ctk.CTkLabel(progress_frame, text="آماده", 
                                         font=ctk.CTkFont(family="B Nazanin", size=10))
        self.progress_label.pack(pady=1)
        
        # Tasks tree (compact version)
        tasks_tree_frame = ctk.CTkFrame(task_frame)
        tasks_tree_frame.pack(fill="both", expand=True, padx=5, pady=2)
        
        tasks_container = tk.Frame(tasks_tree_frame, bg=tasks_tree_frame.cget("fg_color")[1])
        tasks_container.pack(fill="both", expand=True, padx=2, pady=2)
        
        self.task_tree = ttk.Treeview(
            tasks_container,
            columns=("File", "Status", "Progress"),
            show="headings",
            height=10
        )
        
        # Configure compact task tree columns
        self.task_tree.heading("File", text="📁 فایل")
        self.task_tree.heading("Status", text="🔄 وضعیت")
        self.task_tree.heading("Progress", text="📊 پیشرفت")
        
        self.task_tree.column("File", width=120, minwidth=80)
        self.task_tree.column("Status", width=60, minwidth=50)
        self.task_tree.column("Progress", width=60, minwidth=50)
        
        # Task tree scrollbar
        task_v_scrollbar = ttk.Scrollbar(tasks_container, orient="vertical", command=self.task_tree.yview)
        self.task_tree.configure(yscrollcommand=task_v_scrollbar.set)
        
        self.task_tree.grid(row=0, column=0, sticky="nsew")
        task_v_scrollbar.grid(row=0, column=1, sticky="ns")
        
        tasks_container.grid_rowconfigure(0, weight=1)
        tasks_container.grid_columnconfigure(0, weight=1)

    def setup_quick_copy_sidebar(self, parent):
        """Setup the quick copy sidebar with auto-detected destinations"""
        # Sidebar frame
        sidebar_frame = ctk.CTkFrame(parent, width=350)
        sidebar_frame.pack(side="right", fill="y", padx=(5, 0))
        sidebar_frame.pack_propagate(False)  # Maintain fixed width
        
        # Sidebar title
        title_label = ctk.CTkLabel(
            sidebar_frame,
            text="🎯 کپی سریع",
            font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold")
        )
        title_label.pack(pady=(10, 5))
        
        # Instructions
        instruction_label = ctk.CTkLabel(
            sidebar_frame,
            text="فایل‌ها را از لیست انتخاب کنید\nسپس روی پوشه مقصد کلیک کنید",
            font=ctk.CTkFont(family="B Nazanin", size=12),
            wraplength=300
        )
        instruction_label.pack(pady=5)
        
        # Auto-refresh destinations button
        refresh_dest_btn = ctk.CTkButton(
            sidebar_frame,
            text="🔄 بروزرسانی مقاصد",
            command=self.refresh_destinations,
            font=ctk.CTkFont(family="B Nazanin", size=12),
            width=200
        )
        refresh_dest_btn.pack(pady=5)
        
        # Destinations scrollable frame
        self.dest_folders_frame = ctk.CTkScrollableFrame(
            sidebar_frame,
            label_text="📁 پوشه‌های مقصد (شناسایی خودکار)",
            height=500,
            label_font=ctk.CTkFont(family="B Nazanin", size=14, weight="bold")
        )
        self.dest_folders_frame.pack(fill="both", expand=True, padx=10, pady=(10, 10))
        
        # Initialize with auto-detected destinations
        self.update_destination_folders_display()

    def setup_tasks_tab(self):
        """راه‌اندازی تب مدیریت کارها"""
        # دکمه‌های کنترل
        control_frame = ctk.CTkFrame(self.tasks_frame)
        control_frame.pack(fill="x", padx=10, pady=10)
        
        # کنترل‌های اصلی
        main_controls = ctk.CTkFrame(control_frame)
        main_controls.pack(fill="x", pady=(0, 5))
        
        self.start_btn = ctk.CTkButton(main_controls, text="▶ شروع انتخاب شده", command=self.start_selected_task,
                                      fg_color="green", hover_color="darkgreen", font=ctk.CTkFont(family="B Nazanin"))
        self.start_btn.pack(side="right", padx=5)
        
        self.pause_btn = ctk.CTkButton(main_controls, text="⏸ توقف انتخاب شده", command=self.pause_selected_task,
                                      fg_color="orange", hover_color="darkorange", font=ctk.CTkFont(family="B Nazanin"))
        self.pause_btn.pack(side="right", padx=5)
        
        self.cancel_btn = ctk.CTkButton(main_controls, text="⏹ لغو انتخاب شده", command=self.cancel_selected_task,
                                       fg_color="red", hover_color="darkred", font=ctk.CTkFont(family="B Nazanin"))
        self.cancel_btn.pack(side="right", padx=5)
        
        self.restart_btn = ctk.CTkButton(main_controls, text="🔄 شروع مجدد", command=self.restart_selected_task,
                                        fg_color="blue", hover_color="darkblue", font=ctk.CTkFont(family="B Nazanin"))
        self.restart_btn.pack(side="right", padx=5)
        
        # کنترل‌های مدیریت کار
        task_controls = ctk.CTkFrame(control_frame)
        task_controls.pack(fill="x")
        
        ctk.CTkButton(task_controls, text="📋 پاک کردن همه", command=self.clear_all_tasks, font=ctk.CTkFont(family="B Nazanin")).pack(side="right", padx=5)
        ctk.CTkButton(task_controls, text="🗑 پاک کردن تکمیل شده", command=self.clear_completed, font=ctk.CTkFont(family="B Nazanin")).pack(side="right", padx=5)
        ctk.CTkButton(task_controls, text="↓ پایین بردن", command=self.move_task_down, font=ctk.CTkFont(family="B Nazanin")).pack(side="right", padx=5)
        ctk.CTkButton(task_controls, text="↑ بالا بردن", command=self.move_task_up, font=ctk.CTkFont(family="B Nazanin")).pack(side="right", padx=5)
        
        # Progress overview
        progress_frame = ctk.CTkFrame(self.tasks_frame)
        progress_frame.pack(fill="x", padx=10, pady=(0, 10))
        
        self.overall_progress = ctk.CTkProgressBar(progress_frame)
        self.overall_progress.pack(fill="x", padx=10, pady=5)
        self.overall_progress.set(0)
        
        self.progress_label = ctk.CTkLabel(progress_frame, text="هیچ کار فعالی موجود نیست", font=ctk.CTkFont(family="B Nazanin"))
        self.progress_label.pack(pady=5)
        
        # Tasks tree
        tasks_tree_frame = ctk.CTkFrame(self.tasks_frame)
        tasks_tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        tasks_container = tk.Frame(tasks_tree_frame, bg=tasks_tree_frame.cget("fg_color")[1])
        tasks_container.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.task_tree = ttk.Treeview(
            tasks_container,
            columns=("File", "Destination", "Progress", "Size", "Copied", "Speed", "Status"),
            show="headings",
            height=15
        )
        
        # Configure task tree columns
        columns_config = [
            ("File", 250, "📁 File Name", 150),
            ("Destination", 300, "📂 Destination Path", 200),
            ("Progress", 100, "📊 Progress %", 80),
            ("Size", 100, "💾 Total Size", 80),
            ("Copied", 100, "✅ Copied", 80),
            ("Speed", 120, "⚡ Speed (MB/s)", 100),
            ("Status", 150, "🔄 Status", 120)
        ]
        
        for col, width, heading, minwidth in columns_config:
            self.task_tree.heading(col, text=heading)
            self.task_tree.column(col, width=width, minwidth=minwidth, anchor="center")
        
        # Task tree scrollbars
        task_v_scrollbar = ttk.Scrollbar(tasks_container, orient="vertical", command=self.task_tree.yview)
        task_h_scrollbar = ttk.Scrollbar(tasks_container, orient="horizontal", command=self.task_tree.xview)
        
        self.task_tree.configure(yscrollcommand=task_v_scrollbar.set, xscrollcommand=task_h_scrollbar.set)
        
        self.task_tree.grid(row=0, column=0, sticky="nsew")
        task_v_scrollbar.grid(row=0, column=1, sticky="ns")
        task_h_scrollbar.grid(row=1, column=0, sticky="ew")
        
        tasks_container.grid_rowconfigure(0, weight=1)
        tasks_container.grid_columnconfigure(0, weight=1)

    def setup_settings_tab(self):
        """Setup the settings tab"""
        # Create scrollable frame with beautiful styling
        settings_scroll = ctk.CTkScrollableFrame(
            self.settings_frame,
            corner_radius=10,
            fg_color=("gray95", "gray20"),
            scrollbar_button_color=("gray70", "gray30"),
            scrollbar_button_hover_color=("gray60", "gray40")
        )
        settings_scroll.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Performance Settings (Licensed Feature)
        perf_frame = ctk.CTkFrame(
            settings_scroll,
            corner_radius=12,
            fg_color=("white", "gray25"),
            border_width=1,
            border_color=("gray80", "gray35")
        )
        perf_frame.pack(fill="x", pady=10)
        
        perf_header = ctk.CTkFrame(perf_frame, fg_color="transparent")
        perf_header.pack(fill="x", padx=15, pady=(15, 5))
        
        # Check license for advanced settings
        license_text = "⚡ Performance Settings"
        if not self.check_feature_license("advanced_settings"):
            license_text += " 🔒 (نیاز به لایسنس)"
        
        perf_title = ctk.CTkLabel(
            perf_header, 
            text=license_text, 
            font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold"),
            text_color=("red", "orange") if not self.check_feature_license("advanced_settings") else ("gray10", "white")
        )
        perf_title.pack(side="left")
        
        # Performance help button
        perf_help = ctk.CTkButton(
            perf_header,
            text="❓",
            width=30,
            height=30,
            corner_radius=15,
            command=lambda: self.show_help("performance")
        )
        perf_help.pack(side="right")
        
        # Buffer size with slider
        buffer_frame = ctk.CTkFrame(perf_frame, fg_color="transparent")
        buffer_frame.pack(fill="x", padx=15, pady=8)
        
        buffer_header = ctk.CTkFrame(buffer_frame, fg_color="transparent")
        buffer_header.pack(fill="x")
        
        ctk.CTkLabel(
            buffer_header, 
            text="🔧 Buffer Size:", 
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        ).pack(side="left")
        
        self.buffer_var = tk.StringVar(value=str(self.settings.get("buffer_size", 64 * 1024) // 1024))
        buffer_entry = ctk.CTkEntry(
            buffer_header, 
            textvariable=self.buffer_var, 
            width=80,
            placeholder_text="KB",
            state="disabled" if not self.check_feature_license("advanced_settings") else "normal"
        )
        buffer_entry.pack(side="right", padx=5)
        
        ctk.CTkLabel(buffer_header, text="KB").pack(side="right")
        
        # Buffer slider
        self.buffer_slider = ctk.CTkSlider(
            buffer_frame,
            from_=16,
            to=1024,
            number_of_steps=32,
            command=self.update_buffer_from_slider if self.check_feature_license("advanced_settings") else self.show_license_prompt_for_advanced_settings,
            state="disabled" if not self.check_feature_license("advanced_settings") else "normal"
        )
        self.buffer_slider.pack(fill="x", pady=(5, 0))
        self.buffer_slider.set(int(self.buffer_var.get()))
        
        # Buffer recommendation
        buffer_rec = ctk.CTkLabel(
            buffer_frame,
            text="💡 Recommended: SSD=256KB, HDD=64KB, Network=32KB",
            font=ctk.CTkFont(family="B Nazanin", size=10),
            text_color=("gray50", "gray60")
        )
        buffer_rec.pack(pady=(2, 0))
        
        # Max threads with slider
        threads_frame = ctk.CTkFrame(perf_frame, fg_color="transparent")
        threads_frame.pack(fill="x", padx=15, pady=8)
        
        threads_header = ctk.CTkFrame(threads_frame, fg_color="transparent")
        threads_header.pack(fill="x")
        
        ctk.CTkLabel(
            threads_header, 
            text="👥 Max Threads:", 
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        ).pack(side="left")
        
        self.threads_var = tk.StringVar(value=str(self.settings.get("max_threads", 4)))
        threads_entry = ctk.CTkEntry(
            threads_header, 
            textvariable=self.threads_var, 
            width=60
        )
        threads_entry.pack(side="right", padx=5)
        
        # Threads slider
        self.threads_slider = ctk.CTkSlider(
            threads_frame,
            from_=1,
            to=8,
            number_of_steps=7,
            command=self.update_threads_from_slider
        )
        self.threads_slider.pack(fill="x", pady=(5, 0))
        self.threads_slider.set(int(self.threads_var.get()))
        
        # Threads recommendation
        threads_rec = ctk.CTkLabel(
            threads_frame,
            text="💡 Recommended: Large files=1-2, Small files=4-6, Network=2-3",
            font=ctk.CTkFont(family="B Nazanin", size=10),
            text_color=("gray50", "gray60")
        )
        threads_rec.pack(pady=(2, 0))
        
        # Progress update interval
        progress_frame = ctk.CTkFrame(perf_frame, fg_color="transparent")
        progress_frame.pack(fill="x", padx=15, pady=8)
        
        progress_header = ctk.CTkFrame(progress_frame, fg_color="transparent")
        progress_header.pack(fill="x")
        
        ctk.CTkLabel(
            progress_header, 
            text="⏱ Update Interval:", 
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        ).pack(side="left")
        
        self.progress_interval_var = tk.StringVar(value=str(self.settings.get("progress_update_interval", 0.5)))
        progress_entry = ctk.CTkEntry(
            progress_header, 
            textvariable=self.progress_interval_var, 
            width=60,
            placeholder_text="sec"
        )
        progress_entry.pack(side="right", padx=5)
        
        ctk.CTkLabel(progress_header, text="seconds").pack(side="right")
        
        # Progress slider  
        self.progress_slider = ctk.CTkSlider(
            progress_frame,
            from_=0.1,
            to=2.0,
            number_of_steps=19,
            command=self.update_progress_from_slider
        )
        self.progress_slider.pack(fill="x", pady=(5, 0))
        self.progress_slider.set(float(self.progress_interval_var.get()))
        
        # Behavior Settings
        behavior_frame = ctk.CTkFrame(
            settings_scroll,
            corner_radius=12,
            fg_color=("white", "gray25"),
            border_width=1,
            border_color=("gray80", "gray35")
        )
        behavior_frame.pack(fill="x", pady=10)
        
        behavior_header = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        behavior_header.pack(fill="x", padx=15, pady=(15, 5))
        
        ctk.CTkLabel(
            behavior_header, 
            text="🎯 Behavior Settings", 
            font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold"),
            text_color=("gray10", "white")
        ).pack(side="left")
        
        ctk.CTkButton(
            behavior_header,
            text="❓",
            width=30,
            height=30,
            corner_radius=15,
            command=lambda: self.show_help("behavior")
        ).pack(side="right")
        
        # Overwrite policy
        overwrite_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        overwrite_frame.pack(fill="x", padx=15, pady=8)
        
        ctk.CTkLabel(
            overwrite_frame, 
            text="📁 File Exists Policy:", 
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        ).pack(side="left", padx=5)
        
        self.overwrite_var = tk.StringVar(value=self.settings.get("overwrite_policy", "prompt"))
        overwrite_combo = ctk.CTkComboBox(
            overwrite_frame, 
            values=["prompt", "overwrite", "skip"],
            variable=self.overwrite_var, 
            width=120
        )
        overwrite_combo.pack(side="right", padx=5)
        
        # Additional behavior settings
        # Auto retry
        retry_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        retry_frame.pack(fill="x", padx=15, pady=5)
        
        self.auto_retry_var = tk.BooleanVar(value=self.settings.get("auto_retry", True))
        retry_checkbox = ctk.CTkCheckBox(
            retry_frame,
            text="🔄 Auto Retry Failed Operations",
            variable=self.auto_retry_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        retry_checkbox.pack(side="left")
        
        self.retry_count_var = tk.StringVar(value=str(self.settings.get("retry_count", 3)))
        retry_spinbox = ctk.CTkEntry(retry_frame, textvariable=self.retry_count_var, width=50)
        retry_spinbox.pack(side="right", padx=(5, 0))
        ctk.CTkLabel(retry_frame, text="times").pack(side="right")
        
        # Verify copy
        verify_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        verify_frame.pack(fill="x", padx=15, pady=5)
        
        self.verify_copy_var = tk.BooleanVar(value=self.settings.get("verify_copy", True))
        verify_checkbox = ctk.CTkCheckBox(
            verify_frame,
            text="✅ Verify Copy Integrity (slower but safer)",
            variable=self.verify_copy_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        verify_checkbox.pack(side="left")
        
        # Show hidden files
        hidden_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        hidden_frame.pack(fill="x", padx=15, pady=5)
        
        self.show_hidden_var = tk.BooleanVar(value=self.settings.get("show_hidden_files", False))
        hidden_checkbox = ctk.CTkCheckBox(
            hidden_frame,
            text="🗂 Show Hidden Files and Folders",
            variable=self.show_hidden_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        hidden_checkbox.pack(side="left")
        
        # Create backup
        backup_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        backup_frame.pack(fill="x", padx=15, pady=5)
        
        self.create_backup_var = tk.BooleanVar(value=self.settings.get("create_backup", False))
        backup_checkbox = ctk.CTkCheckBox(
            backup_frame,
            text="💾 Create Backup Before Overwriting",
            variable=self.create_backup_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        backup_checkbox.pack(side="left")
        
        # Preserve permissions
        perm_frame = ctk.CTkFrame(behavior_frame, fg_color="transparent")
        perm_frame.pack(fill="x", padx=15, pady=(5, 15))
        
        self.preserve_permissions_var = tk.BooleanVar(value=self.settings.get("preserve_permissions", True))
        perm_checkbox = ctk.CTkCheckBox(
            perm_frame,
            text="🔐 Preserve File Permissions",
            variable=self.preserve_permissions_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        perm_checkbox.pack(side="left")
        
        # Appearance Settings
        appearance_frame = ctk.CTkFrame(
            settings_scroll,
            corner_radius=12,
            fg_color=("white", "gray25"),
            border_width=1,
            border_color=("gray80", "gray35")
        )
        appearance_frame.pack(fill="x", pady=10)
        
        appearance_header = ctk.CTkFrame(appearance_frame, fg_color="transparent")
        appearance_header.pack(fill="x", padx=15, pady=(15, 5))
        
        ctk.CTkLabel(
            appearance_header, 
            text="🎨 Appearance Settings", 
            font=ctk.CTkFont(family="B Nazanin", size=18, weight="bold"),
            text_color=("gray10", "white")
        ).pack(side="left")
        
        ctk.CTkButton(
            appearance_header,
            text="❓",
            width=30,
            height=30,
            corner_radius=15,
            command=lambda: self.show_help("appearance")
        ).pack(side="right")
        
        # Theme section with preview
        theme_section = ctk.CTkFrame(appearance_frame, fg_color="transparent")
        theme_section.pack(fill="x", padx=15, pady=10)
        
        theme_header = ctk.CTkFrame(theme_section, fg_color="transparent")
        theme_header.pack(fill="x", pady=(0, 10))
        
        ctk.CTkLabel(
            theme_header, 
            text="🎨 Theme:", 
            font=ctk.CTkFont(family="B Nazanin", size=14, weight="bold")
        ).pack(side="left", padx=5)
        
        # Theme help button
        ctk.CTkButton(
            theme_header,
            text="❓",
            width=25,
            height=25,
            corner_radius=12,
            command=lambda: self.show_help("appearance")
        ).pack(side="right")
        
        self.theme_var = tk.StringVar(value=self.settings.get("theme", "dark_blue"))
        theme_combo = ctk.CTkComboBox(
            theme_section, 
            values=list(THEMES.keys()),
            variable=self.theme_var, 
            width=200,
            command=self.preview_theme
        )
        theme_combo.pack(fill="x", padx=5, pady=5)
        
        # Theme preview
        self.theme_preview = ctk.CTkFrame(
            theme_section,
            height=60,
            corner_radius=8,
            fg_color=("gray90", "gray20")
        )
        self.theme_preview.pack(fill="x", padx=5, pady=5)
        self.theme_preview.pack_propagate(False)
        
        ctk.CTkLabel(
            self.theme_preview,
            text="🎨 Theme Preview",
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        ).pack(pady=20)
        
        # Additional appearance settings
        # Notification settings
        notification_frame = ctk.CTkFrame(appearance_frame, fg_color="transparent")
        notification_frame.pack(fill="x", padx=15, pady=5)
        
        self.notification_sound_var = tk.BooleanVar(value=self.settings.get("notification_sound", True))
        notification_checkbox = ctk.CTkCheckBox(
            notification_frame,
            text="🔔 Play Completion Sound",
            variable=self.notification_sound_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        notification_checkbox.pack(side="left")
        
        # Show speed graph
        graph_frame = ctk.CTkFrame(appearance_frame, fg_color="transparent")
        graph_frame.pack(fill="x", padx=15, pady=5)
        
        self.show_speed_graph_var = tk.BooleanVar(value=self.settings.get("show_speed_graph", True))
        graph_checkbox = ctk.CTkCheckBox(
            graph_frame,
            text="📊 Show Speed Graph",
            variable=self.show_speed_graph_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        graph_checkbox.pack(side="left")
        
        # Auto clear completed
        auto_clear_frame = ctk.CTkFrame(appearance_frame, fg_color="transparent")
        auto_clear_frame.pack(fill="x", padx=15, pady=(5, 15))
        
        self.auto_clear_completed_var = tk.BooleanVar(value=self.settings.get("auto_clear_completed", False))
        auto_clear_checkbox = ctk.CTkCheckBox(
            auto_clear_frame,
            text="🗑 Auto Clear Completed Tasks",
            variable=self.auto_clear_completed_var,
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold")
        )
        auto_clear_checkbox.pack(side="left")
        
        # Save button with enhanced styling
        save_frame = ctk.CTkFrame(
            settings_scroll,
            fg_color="transparent"
        )
        save_frame.pack(fill="x", pady=20)
        
        save_button = ctk.CTkButton(
            save_frame, 
            text="💾 Save All Settings", 
            command=self.save_settings_from_gui,
            font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold"), 
            height=50,
            corner_radius=25,
            fg_color=("green", "darkgreen"),
            hover_color=("darkgreen", "green")
        )
        save_button.pack(pady=10)
        
        # Reset to defaults button
        reset_button = ctk.CTkButton(
            save_frame,
            text="🔄 Reset to Defaults",
            command=self.reset_settings_to_defaults,
            font=ctk.CTkFont(family="B Nazanin", size=12),
            height=35,
            corner_radius=17,
            fg_color=("orange", "darkorange"),
            hover_color=("darkorange", "orange")
        )
        reset_button.pack(pady=(0, 10))

    def setup_status_bar(self):
        """Setup the status bar"""
        status_frame = ctk.CTkFrame(self.main_frame, height=30)
        status_frame.pack(fill="x", side="bottom")
        status_frame.pack_propagate(False)
        
        self.status_label = ctk.CTkLabel(status_frame, text="Ready", anchor="w")
        self.status_label.pack(side="left", padx=10, pady=5, fill="x", expand=True)
        
        self.file_count_label = ctk.CTkLabel(status_frame, text="Files: 0")
        self.file_count_label.pack(side="right", padx=10, pady=5)

    def setup_bindings(self):
        """Setup event bindings"""
        try:
            if hasattr(self, 'search_entry') and self.search_entry:
                self.search_entry.bind("<KeyRelease>", self.on_search_change)
            if hasattr(self, 'file_tree') and self.file_tree:
                self.file_tree.bind("<Double-1>", self.on_file_double_click)
            if hasattr(self, 'task_tree') and self.task_tree:
                self.task_tree.bind("<Double-1>", self.on_task_double_click)
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.bind("<Configure>", self.on_window_resize)
        except Exception as e:
            print(f"Error setting up bindings: {e}")

    def update_status(self, message: str):
        """Update status bar message"""
        try:
            if hasattr(self, 'status_label') and self.status_label:
                self.status_label.configure(text=message)
                self.root.update_idletasks()
            else:
                # If status label not ready yet, just print to console
                print(f"Status: {message}")
        except Exception as e:
            print(f"Error updating status: {e}, Message: {message}")

    def format_size(self, size_bytes: int) -> str:
        """Format file size in human readable format"""
        if size_bytes == 0:
            return "0 B"
        
        size_names = ["B", "KB", "MB", "GB", "TB"]
        i = 0
        while size_bytes >= 1024 and i < len(size_names) - 1:
            size_bytes /= 1024.0
            i += 1
        
        return f"{size_bytes:.1f} {size_names[i]}"

    def get_file_size(self, path: str) -> int:
        """Get size of file or directory"""
        try:
            if os.path.isfile(path):
                return os.path.getsize(path)
            elif os.path.isdir(path):
                total_size = 0
                for dirpath, dirnames, filenames in os.walk(path):
                    for filename in filenames:
                        file_path = os.path.join(dirpath, filename)
                        try:
                            total_size += os.path.getsize(file_path)
                        except (OSError, IOError):
                            continue
                return total_size
            return 0
        except (OSError, IOError):
            return 0

    def browse_directory(self):
        """Browse for a directory"""
        directory = filedialog.askdirectory(initialdir=self.current_dir)
        if directory:
            self.current_dir = directory
            self.current_dir_label.configure(text=directory)
            self.refresh_files()

    def go_home(self):
        """Go to home directory"""
        self.current_dir = os.path.expanduser("~")
        self.current_dir_label.configure(text=self.current_dir)
        self.refresh_files()

    def browse_dest(self):
        """Browse for destination directory"""
        directory = filedialog.askdirectory()
        if directory:
            self.dest_entry.delete(0, tk.END)
            self.dest_entry.insert(0, directory)

    def refresh_all_files(self):
        """Refresh all files from all drives"""
        self.update_status("بروزرسانی همه فایل‌ها از تمام درایوها...")
        threading.Thread(target=self.initial_system_scan, daemon=True).start()

    def refresh_files(self):
        """Legacy method - redirects to refresh_all_files"""
        self.refresh_all_files()

    def _refresh_files_thread(self):
        """Thread function to refresh files"""
        try:
            if not os.path.exists(self.current_dir):
                self.root.after(0, lambda: self.update_status("Directory not found"))
                return
            
            files_data = []
            file_count = 0
            
            for item in os.listdir(self.current_dir):
                item_path = os.path.join(self.current_dir, item)
                try:
                    if os.path.isfile(item_path):
                        size = self.get_file_size(item_path)
                        files_data.append((item, item_path, "File", self.format_size(size)))
                    elif os.path.isdir(item_path):
                        files_data.append((item, item_path, "Directory", ""))
                    file_count += 1
                except (OSError, IOError):
                    continue
            
            # Update cache
            self.file_cache["files"] = {
                item_path: {"name": name, "type": file_type, "size": size_str}
                for name, item_path, file_type, size_str in files_data
            }
            self.file_cache["last_scan"] = time.time()
            self.save_cache()
            
            # Update GUI
            self.root.after(0, lambda: self._update_file_tree(files_data, file_count))
            
        except Exception as e:
            self.logger.error(f"Error refreshing files: {e}")
            self.root.after(0, lambda: self.update_status(f"Error: {e}"))

    def _update_file_tree(self, files_data: List, file_count: int):
        """Update file tree with new data"""
        try:
            self.file_tree.delete(*self.file_tree.get_children())
            
            for file_info in files_data:
                if len(file_info) == 4:
                    # Old format: name, path, file_type, size
                    name, path, file_type, size = file_info
                    drive = ""
                elif len(file_info) == 5:
                    # New format: name, path, file_type, size, drive
                    name, path, file_type, size, drive = file_info
                else:
                    continue
                    
                self.file_tree.insert("", "end", values=(name, path, file_type, size, drive))
            
            if hasattr(self, 'file_count_label'):
                self.file_count_label.configure(text=f"Files: {file_count}")
            self.update_status("Ready")
        except Exception as e:
            print(f"Error updating file tree: {e}")

    def display_cache(self):
        """Display cached files"""
        try:
            self.file_tree.delete(*self.file_tree.get_children())
            file_count = 0
            
            for item_path, data in self.file_cache.get("files", {}).items():
                if os.path.exists(item_path):
                    size_str = data.get("size", "")
                    drive_info = data.get("drive", "")
                    self.file_tree.insert("", "end", values=(
                        data["name"], item_path, data["type"], size_str, drive_info
                    ))
                    file_count += 1
            
            if hasattr(self, 'file_count_label'):
                self.file_count_label.configure(text=f"Files: {file_count}")
        except Exception as e:
            print(f"Error displaying cache: {e}")

    def on_search_change(self, event):
        """Handle search entry changes"""
        search_term = self.search_entry.get().lower().strip()
        if not search_term:
            self.display_cache()
            return
        
        self.update_status("Searching...")
        threading.Thread(target=self._search_files_thread, args=(search_term,), daemon=True).start()

    def _search_files_thread(self, search_term: str):
        """Thread function to search files"""
        try:
            filtered_files = []
            file_count = 0
            
            for item_path, data in self.file_cache.get("files", {}).items():
                if not os.path.exists(item_path):
                    continue
                
                name = data["name"].lower()
                
                # Check if search term matches name or extension
                if (search_term in name or 
                    (search_term.startswith(".") and name.endswith(search_term))):
                    size_str = data.get("size", "")
                    drive_info = data.get("drive", "")
                    filtered_files.append((data["name"], item_path, data["type"], size_str, drive_info))
                    file_count += 1
            
            self.root.after(0, lambda: self._update_file_tree(filtered_files, file_count))
            
        except Exception as e:
            self.logger.error(f"Error searching files: {e}")
            self.root.after(0, lambda: self.update_status("Search error"))

    def clear_search(self):
        """Clear search and show all files"""
        self.search_entry.delete(0, tk.END)
        self.display_cache()

    def select_all_files(self):
        """Select all files in the tree"""
        for item in self.file_tree.get_children():
            self.file_tree.selection_add(item)

    def clear_selection(self):
        """Clear file selection"""
        self.file_tree.selection_remove(*self.file_tree.selection())

    def add_to_queue(self):
        """Add selected files to copy queue"""
        selected_items = self.file_tree.selection()
        if not selected_items:
            messagebox.showwarning("Warning", "Please select files to add to queue!")
            return
        
        destination = self.dest_entry.get().strip()
        if not destination:
            messagebox.showerror("Error", "Please select a destination directory!")
            return
        
        if not os.path.exists(destination):
            messagebox.showerror("Error", "Destination directory does not exist!")
            return
        
        added_count = 0
        for item in selected_items:
            values = self.file_tree.item(item, "values")
            if len(values) >= 2:
                source_path = values[1]  # Full path
                if source_path not in [task["source"] for task in self.copy_tasks]:
                    self.add_task(source_path, destination)
                    added_count += 1
        
        if added_count > 0:
            self.update_status(f"Added {added_count} files to queue")
            # Switch to tasks tab
            self.notebook.select(1)
        else:
            messagebox.showinfo("Info", "Selected files are already in the queue!")

    def add_task(self, source: str, destination: str):
        """Add a copy task to the queue"""
        if not os.path.exists(source):
            return
        
        task_id = len(self.copy_tasks)
        filename = os.path.basename(source)
        dest_path = os.path.join(destination, filename)
        file_size = self.get_file_size(source)
        
        task = {
            "id": task_id,
            "source": source,
            "destination": dest_path,
            "filename": filename,
            "size": file_size,
            "copied": 0,
            "progress": 0.0,
            "speed": 0.0,
            "status": "⏳ Pending",
            "paused": False,
            "cancelled": False,
            "completed": False,
            "start_time": 0,
            "last_update": 0,
            "retry_count": 0,
            "error_message": "",
            "future": None
        }
        
        self.copy_tasks.append(task)
        
        # Add to task tree
        self.task_tree.insert("", "end", iid=str(task_id), values=(
            filename,
            dest_path,
            "0%",
            self.format_size(file_size),
            "0 B",
            "0.0",
            "⏳ Pending"
        ))
        
        self.update_overall_progress()

    def get_selected_task(self):
        """Get the currently selected task"""
        selected = self.task_tree.selection()
        if not selected:
            messagebox.showinfo("انتخاب تسک", "لطفاً یک تسک را انتخاب کنید!")
            return None
        
        task_id = int(selected[0])
        if task_id >= len(self.copy_tasks):
            return None
        
        return self.copy_tasks[task_id]
    
    def start_selected_task(self):
        """Start the selected task"""
        task = self.get_selected_task()
        if not task:
            return
        
        if task["status"] in ["⏳ Pending", "❌ Cancelled", "❌ Error", "⏸ Paused"]:
            task["status"] = "🔄 Running"
            task["cancelled"] = False
            task["paused"] = False
            task["start_time"] = time.time()
            task["last_update"] = time.time()
            task["future"] = self.executor.submit(self.copy_task, task)
            self.update_task_display(task)
            self.update_status(f"شروع کپی: {task['filename']}")
            
            # Update copying state but keep buttons enabled for individual control
            self.is_copying = True
        else:
            messagebox.showinfo("خطا", f"این تسک قابل شروع نیست! وضعیت فعلی: {task['status']}")

    def preview_theme(self, theme_name: str):
        """Preview selected theme"""
        try:
            theme_config = THEMES.get(theme_name, THEMES["dark_blue"])
            
            # Update preview colors based on theme
            if "dark" in theme_name.lower():
                preview_color = ("gray20", "gray30")
                text_color = ("white", "gray90")
            else:
                preview_color = ("gray90", "gray80")
                text_color = ("gray10", "gray20")
            
            self.theme_preview.configure(fg_color=preview_color)
            
            # Update preview text
            for widget in self.theme_preview.winfo_children():
                if isinstance(widget, ctk.CTkLabel):
                    widget.configure(text_color=text_color)
                    
        except Exception as e:
            self.logger.error(f"Error previewing theme: {e}")

    def copy_task(self, task: Dict):
        """Copy a single file/directory with enhanced error handling"""
        try:
            task["status"] = "🔄 Running"
            task["start_time"] = time.time()
            task["last_update"] = time.time()
            
            self.root.after(0, lambda: self.update_task_display(task))
            
            source = task["source"]
            destination = task["destination"]
            
            # Check disk space first
            if not self.check_disk_space(os.path.dirname(destination), task["size"]):
                raise Exception("Insufficient disk space")
            
            # Check if destination exists
            if os.path.exists(destination):
                policy = self.settings.get("overwrite_policy", "prompt")
                if policy == "skip":
                    task["status"] = "⏭ Skipped"
                    self.root.after(0, lambda: self.update_task_display(task))
                    return
                elif policy == "prompt":
                    # For now, just overwrite - in a real app you'd show a dialog
                    pass
                elif policy == "overwrite":
                    if self.settings.get("create_backup", False):
                        backup_path = destination + ".bak"
                        shutil.copy2(destination, backup_path)
            
            # Ensure destination directory exists
            dest_dir = os.path.dirname(destination)
            os.makedirs(dest_dir, exist_ok=True)
            
            # Copy the file/directory
            if os.path.isfile(source):
                self.copy_file(task)
            elif os.path.isdir(source):
                self.copy_directory(task)
            
            # Verify copy if enabled
            if self.settings.get("verify_copy", False) and not task["cancelled"]:
                if not self.verify_copy(source, destination):
                    raise Exception("Copy verification failed")
            
            if not task["cancelled"]:
                task["status"] = "✅ Completed"
                task["progress"] = 100.0
                task["copied"] = task["size"]
                task["completed"] = True
                task["completion_time"] = time.time()  # Record completion time for auto-cleanup
                self.root.after(0, lambda: self.update_task_display(task))
                self.logger.info(f"Successfully copied {source} to {destination}")
                
                # Play notification sound if enabled
                if self.settings.get("notification_sound", False):
                    self.play_notification_sound()
            
        except Exception as e:
            error_msg = str(e)
            task["error_message"] = error_msg
            
            # Auto retry if enabled
            if (self.settings.get("auto_retry", False) and 
                task["retry_count"] < self.settings.get("retry_count", 3) and
                "space" not in error_msg.lower()):
                
                task["retry_count"] += 1
                task["status"] = f"🔄 Retry {task['retry_count']}"
                self.root.after(2000, lambda: self.copy_task(task))  # Retry after 2 seconds
            else:
                task["status"] = f"❌ Error: {error_msg}"
                self.root.after(0, lambda: self.update_task_display(task))
                self.logger.error(f"Failed to copy {task['source']}: {e}")
        
        finally:
            self.root.after(0, self.check_all_tasks_complete)
    
    def verify_copy(self, source: str, destination: str) -> bool:
        """Verify that the copy was successful"""
        try:
            if os.path.isfile(source) and os.path.isfile(destination):
                return os.path.getsize(source) == os.path.getsize(destination)
            elif os.path.isdir(source) and os.path.isdir(destination):
                # Simple verification - check if all files exist
                for root, dirs, files in os.walk(source):
                    for file in files:
                        src_file = os.path.join(root, file)
                        rel_path = os.path.relpath(src_file, source)
                        dst_file = os.path.join(destination, rel_path)
                        if not os.path.exists(dst_file):
                            return False
                return True
            return False
        except:
            return False
    
    def play_notification_sound(self):
        """Play a notification sound"""
        try:
            # Simple system beep - can be enhanced with actual sound files
            import winsound
            winsound.Beep(1000, 200)
        except:
            # On non-Windows systems, try system bell
            try:
                print('\a')  # ASCII bell character
            except:
                pass

    def copy_file(self, task: Dict):
        """Copy a single file with optimized speed and progress tracking"""
        source = task["source"]
        destination = task["destination"]
        
        # Dynamic buffer size based on file size for optimal speed
        file_size = task["size"]
        if file_size < 1024 * 1024:  # < 1MB
            buffer_size = 32 * 1024  # 32KB
        elif file_size < 100 * 1024 * 1024:  # < 100MB
            buffer_size = 512 * 1024  # 512KB
        elif file_size < 1024 * 1024 * 1024:  # < 1GB
            buffer_size = 2 * 1024 * 1024  # 2MB
        else:  # >= 1GB
            buffer_size = 8 * 1024 * 1024  # 8MB
            
        copied_since_update = 0
        update_interval = 0.25  # Update every 0.25 seconds for smoother UI
        
        try:
            with open(source, 'rb') as src, open(destination, 'wb') as dst:
                while not task["cancelled"]:
                    # Handle pause
                    while task["paused"] and not task["cancelled"]:
                        time.sleep(0.1)
                    
                    if task["cancelled"]:
                        break
                    
                    chunk = src.read(buffer_size)
                    if not chunk:
                        break
                    
                    dst.write(chunk)
                    dst.flush()  # Force write to disk for better reliability
                    chunk_size = len(chunk)
                    task["copied"] += chunk_size
                    copied_since_update += chunk_size
                    
                    # Update progress periodically
                    current_time = time.time()
                    if current_time - task["last_update"] >= update_interval:
                        elapsed = current_time - task["last_update"]
                        if elapsed > 0:
                            task["speed"] = (copied_since_update / (1024 * 1024)) / elapsed  # MB/s
                        task["progress"] = (task["copied"] / task["size"]) * 100 if task["size"] > 0 else 0
                        task["last_update"] = current_time
                        copied_since_update = 0
                        
                        self.root.after(0, lambda: self.update_task_display(task))
                        
        except PermissionError:
            raise Exception("دسترسی به فایل مقصد امکان‌پذیر نیست")
        except IOError as e:
            raise Exception(f"خطا در خواندن/نوشتن فایل: {str(e)}")
        except Exception as e:
            raise Exception(f"خطای غیرمنتظره: {str(e)}")

    def copy_directory(self, task: Dict):
        """Copy a directory with optimized progress tracking"""
        source = task["source"]
        destination = task["destination"]
        
        copied_since_update = 0
        update_interval = 0.5  # Update every 0.5 seconds for directories
        
        # Use shutil.copytree with custom copy function for progress
        def copy_with_progress(src, dst, *, follow_symlinks=True):
            nonlocal copied_since_update
            
            if task["cancelled"]:
                return
            
            # Handle pause
            while task["paused"] and not task["cancelled"]:
                time.sleep(0.1)
            
            if task["cancelled"]:
                return
            
            try:
                shutil.copy2(src, dst, follow_symlinks=follow_symlinks)
                
                # Update progress
                file_size = os.path.getsize(dst)  # Use destination size after copy
                task["copied"] += file_size
                copied_since_update += file_size
                task["progress"] = (task["copied"] / task["size"]) * 100 if task["size"] > 0 else 0
                
                current_time = time.time()
                if current_time - task["last_update"] >= update_interval:
                    elapsed = current_time - task["last_update"]
                    if elapsed > 0:
                        task["speed"] = (copied_since_update / (1024 * 1024)) / elapsed
                    task["last_update"] = current_time
                    copied_since_update = 0
                    self.root.after(0, lambda: self.update_task_display(task))
                    
            except PermissionError:
                self.logger.warning(f"Permission denied copying {src} to {dst}")
            except Exception as e:
                self.logger.warning(f"Error copying file {src}: {e}")
        
        try:
            # Create destination directory if it doesn't exist
            os.makedirs(destination, exist_ok=True)
            shutil.copytree(source, destination, copy_function=copy_with_progress, dirs_exist_ok=True)
        except shutil.Error as e:
            # Handle partial copy errors - continue with what we can copy
            self.logger.warning(f"Partial copy error for {source}: {e}")
        except PermissionError:
            raise Exception("دسترسی به پوشه مقصد امکان‌پذیر نیست")
        except Exception as e:
            raise Exception(f"خطا در کپی پوشه: {str(e)}")

    def update_task_display(self, task: Dict):
        """Update task display in the tree"""
        try:
            task_id = str(task["id"])
            if self.task_tree.exists(task_id):
                self.task_tree.set(task_id, "Progress", f"{task['progress']:.1f}%")
                self.task_tree.set(task_id, "Copied", self.format_size(task["copied"]))
                self.task_tree.set(task_id, "Speed", f"{task['speed']:.1f}")
                self.task_tree.set(task_id, "Status", task["status"])
            
            self.update_overall_progress()
        except Exception as e:
            self.logger.error(f"Error updating task display: {e}")

    def update_overall_progress(self):
        """Update overall progress bar and label"""
        if not self.copy_tasks:
            self.overall_progress.set(0)
            self.progress_label.configure(text="No tasks")
            return
        
        total_size = sum(task["size"] for task in self.copy_tasks)
        total_copied = sum(task["copied"] for task in self.copy_tasks)
        
        if total_size > 0:
            progress = total_copied / total_size
            self.overall_progress.set(progress)
        else:
            self.overall_progress.set(0)
        
        # Count tasks by status
        status_counts = {}
        for task in self.copy_tasks:
            status = task["status"]
            status_counts[status] = status_counts.get(status, 0) + 1
        
        status_text = ", ".join([f"{status}: {count}" for status, count in status_counts.items()])
        self.progress_label.configure(text=status_text)

    def pause_selected_task(self):
        """Pause/resume the selected task"""
        task = self.get_selected_task()
        if not task:
            return
        
        if task["status"] == "🔄 Running":
            task["paused"] = True
            task["status"] = "⏸ Paused"
            self.update_task_display(task)
            self.update_status(f"توقف: {task['filename']}")
        elif task["status"] == "⏸ Paused":
            task["paused"] = False
            task["status"] = "🔄 Running"
            self.update_task_display(task)
            self.update_status(f"ادامه: {task['filename']}")
        else:
            messagebox.showinfo("خطا", "این تسک قابل توقف/ادامه نیست!")

    def cancel_selected_task(self):
        """Cancel the selected task"""
        task = self.get_selected_task()
        if not task:
            return
        
        if task["status"] in ["🔄 Running", "⏸ Paused", "⏳ Pending"]:
            if messagebox.askyesno("تأیید", f"آیا می‌خواهید تسک '{task['filename']}' را لغو کنید؟"):
                task["cancelled"] = True
                task["status"] = "❌ Cancelled"
                if task.get("future"):
                    task["future"].cancel()
                self.update_task_display(task)
                self.update_status(f"لغو شد: {task['filename']}")
        else:
            messagebox.showinfo("خطا", "این تسک قابل لغو نیست!")
    
    def restart_selected_task(self):
        """Restart the selected task"""
        task = self.get_selected_task()
        if not task:
            return
        
        if task["status"] in ["✅ Completed", "❌ Cancelled", "❌ Error"]:
            # Reset task
            task["copied"] = 0
            task["progress"] = 0.0
            task["speed"] = 0.0
            task["cancelled"] = False
            task["paused"] = False
            task["retry_count"] = 0
            task["error_message"] = ""
            
            # Start the task
            task["status"] = "🔄 Running"
            task["start_time"] = time.time()
            task["future"] = self.executor.submit(self.copy_task, task)
            self.update_task_display(task)
            self.update_status(f"شروع مجدد: {task['filename']}")
        else:
            messagebox.showinfo("خطا", "این تسک قابل شروع مجدد نیست!")

    def move_task_up(self):
        """Move selected task up in the queue"""
        selected = self.task_tree.selection()
        if not selected:
            return
        
        task_id = int(selected[0])
        if task_id > 0:
            # Swap tasks
            self.copy_tasks[task_id], self.copy_tasks[task_id - 1] = \
                self.copy_tasks[task_id - 1], self.copy_tasks[task_id]
            
            # Update IDs
            self.copy_tasks[task_id]["id"] = task_id
            self.copy_tasks[task_id - 1]["id"] = task_id - 1
            
            self.refresh_task_tree()
            self.task_tree.selection_set(str(task_id - 1))

    def move_task_down(self):
        """Move selected task down in the queue"""
        selected = self.task_tree.selection()
        if not selected:
            return
        
        task_id = int(selected[0])
        if task_id < len(self.copy_tasks) - 1:
            # Swap tasks
            self.copy_tasks[task_id], self.copy_tasks[task_id + 1] = \
                self.copy_tasks[task_id + 1], self.copy_tasks[task_id]
            
            # Update IDs
            self.copy_tasks[task_id]["id"] = task_id
            self.copy_tasks[task_id + 1]["id"] = task_id + 1
            
            self.refresh_task_tree()
            self.task_tree.selection_set(str(task_id + 1))

    def clear_completed(self):
        """Clear completed tasks"""
        completed_statuses = ["✅ Completed", "❌ Cancelled", "⏭ Skipped"]
        initial_count = len(self.copy_tasks)
        self.copy_tasks = [task for task in self.copy_tasks 
                          if not any(status in task["status"] for status in completed_statuses)]
        
        # Reassign IDs
        for i, task in enumerate(self.copy_tasks):
            task["id"] = i
        
        self.refresh_task_tree()
        cleared_count = initial_count - len(self.copy_tasks)
        self.update_status(f"پاک شد: {cleared_count} تسک تکمیل شده. باقی‌مانده: {len(self.copy_tasks)}")

    def clear_all_tasks(self):
        """Clear all tasks"""
        if messagebox.askyesno("تأیید", "همه تسک‌ها پاک شوند؟ این عمل تسک‌های در حال اجرا را لغو می‌کند."):
            # Cancel all active tasks first
            for task in self.copy_tasks:
                if task["status"] in ["🔄 Running", "⏸ Paused", "⏳ Pending"]:
                    task["cancelled"] = True
                    task["status"] = "❌ Cancelled"
                    if task.get("future"):
                        task["future"].cancel()
            
            self.copy_tasks.clear()
            self.refresh_task_tree()
            self.update_status("همه تسک‌ها پاک شدند")

    def refresh_task_tree(self):
        """Refresh the task tree display"""
        self.task_tree.delete(*self.task_tree.get_children())
        
        for task in self.copy_tasks:
            self.task_tree.insert("", "end", iid=str(task["id"]), values=(
                task["filename"],
                task["destination"],
                f"{task['progress']:.1f}%",
                self.format_size(task["size"]),
                self.format_size(task["copied"]),
                f"{task['speed']:.1f}",
                task["status"]
            ))
        
        self.update_overall_progress()

    def check_all_tasks_complete(self):
        """Check if all tasks are complete"""
        active_tasks = [task for task in self.copy_tasks 
                       if task["status"] in ["🔄 Running", "⏳ Pending"]]
        
        if not active_tasks and self.is_copying:
            self.is_copying = False
            self.start_btn.configure(state="normal")
            self.update_status("همه تسک‌ها تکمیل شدند!")
            
            # Show completion notification
            completed_count = len([task for task in self.copy_tasks if task["status"] == "✅ Completed"])
            if completed_count > 0:
                messagebox.showinfo("اتمام کار", f"{completed_count} عملیات کپی با موفقیت تکمیل شد!")

    def save_settings_from_gui(self):
        """Save settings from GUI controls"""
        try:
            # Validate and save buffer size
            buffer_kb = int(self.buffer_var.get())
            if buffer_kb < 1 or buffer_kb > 1024:
                raise ValueError("Buffer size must be between 1 and 1024 KB")
            self.settings["buffer_size"] = buffer_kb * 1024
            
            # Validate and save max threads
            max_threads = int(self.threads_var.get())
            if max_threads < 1 or max_threads > 8:
                raise ValueError("Max threads must be between 1 and 8")
            self.settings["max_threads"] = max_threads
            
            # Validate and save progress interval
            progress_interval = float(self.progress_interval_var.get())
            if progress_interval < 0.1 or progress_interval > 2.0:
                raise ValueError("Progress update interval must be between 0.1 and 2.0 seconds")
            self.settings["progress_update_interval"] = progress_interval
            
            # Validate retry count
            retry_count = int(self.retry_count_var.get())
            if retry_count < 1 or retry_count > 10:
                raise ValueError("Retry count must be between 1 and 10")
            self.settings["retry_count"] = retry_count
            
            # Save behavior settings
            self.settings["overwrite_policy"] = self.overwrite_var.get()
            self.settings["auto_retry"] = self.auto_retry_var.get()
            self.settings["verify_copy"] = self.verify_copy_var.get()
            self.settings["show_hidden_files"] = self.show_hidden_var.get()
            self.settings["create_backup"] = self.create_backup_var.get()
            self.settings["preserve_permissions"] = self.preserve_permissions_var.get()
            
            # Save appearance settings
            new_theme = self.theme_var.get()
            self.settings["theme"] = new_theme
            self.settings["notification_sound"] = self.notification_sound_var.get()
            self.settings["show_speed_graph"] = self.show_speed_graph_var.get()
            self.settings["auto_clear_completed"] = self.auto_clear_completed_var.get()
            
            # Apply theme change
            theme_config = THEMES.get(new_theme, THEMES["dark_blue"])
            ctk.set_appearance_mode(theme_config["mode"])
            ctk.set_default_color_theme(theme_config["color"])
            
            # Restart executor with new thread count
            if self.executor:
                self.executor.shutdown(wait=False)
            self.setup_executor()
            
            self.save_settings()
            
            # Success notification
            success_window = ctk.CTkToplevel(self.root)
            success_window.title("Settings Saved")
            success_window.geometry("300x150")
            success_window.transient(self.root)
            success_window.grab_set()
            
            # Center the window
            success_window.update_idletasks()
            x = (success_window.winfo_screenwidth() // 2) - (300 // 2)
            y = (success_window.winfo_screenheight() // 2) - (150 // 2)
            success_window.geometry(f"300x150+{x}+{y}")
            
            ctk.CTkLabel(
                success_window,
                text="✅ Settings Saved Successfully!",
                font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold")
            ).pack(pady=30)
            
            ctk.CTkButton(
                success_window,
                text="OK",
                command=success_window.destroy,
                width=100
            ).pack(pady=10)
            
            # Auto close after 2 seconds
            success_window.after(2000, success_window.destroy)
            
        except ValueError as e:
            messagebox.showerror("Invalid Input", str(e))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save settings: {e}")
    
    def reset_settings_to_defaults(self):
        """Reset all settings to default values"""
        if messagebox.askyesno("Reset Settings", "Are you sure you want to reset all settings to defaults?"):
            try:
                # Reset to default values
                self.buffer_var.set("64")
                self.buffer_slider.set(64)
                
                self.threads_var.set("4")
                self.threads_slider.set(4)
                
                self.progress_interval_var.set("0.5")
                self.progress_slider.set(0.5)
                
                self.retry_count_var.set("3")
                
                # Reset checkboxes
                self.auto_retry_var.set(True)
                self.verify_copy_var.set(True)
                self.show_hidden_var.set(False)
                self.create_backup_var.set(False)
                self.preserve_permissions_var.set(True)
                self.notification_sound_var.set(True)
                self.show_speed_graph_var.set(True)
                self.auto_clear_completed_var.set(False)
                
                # Reset comboboxes
                self.overwrite_var.set("prompt")
                self.theme_var.set("dark_blue")
                
                # Update preview
                self.preview_theme("dark_blue")
                
                messagebox.showinfo("Settings Reset", "All settings have been reset to defaults!")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to reset settings: {e}")

    def on_file_double_click(self, event):
        """Handle double-click on file tree"""
        item = self.file_tree.selection()[0] if self.file_tree.selection() else None
        if item:
            values = self.file_tree.item(item, "values")
            if len(values) >= 3 and values[2] == "Directory":
                # Navigate to directory
                self.current_dir = values[1]
                self.current_dir_label.configure(text=self.current_dir)
                self.refresh_files()

    def on_task_double_click(self, event):
        """Handle double-click on task tree"""
        task = self.get_selected_task()
        if task:
            if task["status"] in ["🔄 Running"]:
                self.pause_selected_task()
            elif task["status"] in ["⏸ Paused", "⏳ Pending"]:
                self.start_selected_task()

    
    
    def start_individual_task(self, task_id: int):
        """Start an individual task"""
        if task_id >= len(self.copy_tasks):
            return
        
        task = self.copy_tasks[task_id]
        if task["status"] in ["⏳ Pending", "❌ Cancelled", "❌ Error", "⏸ Paused"]:
            task["status"] = "🔄 Running"
            task["cancelled"] = False
            task["paused"] = False
            task["start_time"] = time.time()
            task["future"] = self.executor.submit(self.copy_task, task)
            self.update_task_display(task)
    
    def pause_individual_task(self, task_id: int):
        """Pause/resume an individual task"""
        if task_id >= len(self.copy_tasks):
            return
        
        task = self.copy_tasks[task_id]
        if task["status"] == "🔄 Running":
            task["paused"] = True
            task["status"] = "⏸ Paused"
            self.update_task_display(task)
    
    def cancel_individual_task(self, task_id: int):
        """Cancel an individual task"""
        if task_id >= len(self.copy_tasks):
            return
        
        task = self.copy_tasks[task_id]
        if task["status"] in ["🔄 Running", "⏸ Paused", "⏳ Pending"]:
            task["cancelled"] = True
            task["status"] = "❌ Cancelled"
            if task.get("future"):
                task["future"].cancel()
            self.update_task_display(task)
    
    def restart_individual_task(self, task_id: int):
        """Restart a cancelled or failed task"""
        if task_id >= len(self.copy_tasks):
            return
        
        task = self.copy_tasks[task_id]
        task["copied"] = 0
        task["progress"] = 0.0
        task["speed"] = 0.0
        task["cancelled"] = False
        task["paused"] = False
        task["retry_count"] = 0
        task["error_message"] = ""
        self.start_individual_task(task_id)
    
    def remove_individual_task(self, task_id: int):
        """Remove a completed task from the list"""
        if task_id >= len(self.copy_tasks):
            return
        
        task = self.copy_tasks[task_id]
        if task["status"] in ["✅ Completed", "❌ Cancelled", "❌ Error"]:
            # Remove the task
            del self.copy_tasks[task_id]
            
            # Reassign IDs to remaining tasks
            for i, remaining_task in enumerate(self.copy_tasks):
                remaining_task["id"] = i
            
            # Refresh the tree view
            self.refresh_task_tree()
            self.update_status(f"Removed task. {len(self.copy_tasks)} remaining.")
    
    def show_help(self, section: str):
        """Show help information for settings sections"""
        help_texts = {
            "performance": """⚡ Performance Settings Help:

🔧 Buffer Size (1-1024 KB):
• Small files (< 1MB): 32-64 KB - Faster for many small files
• Large files (> 100MB): 256-512 KB - Better for big files  
• SSD storage: 256-512 KB - Take advantage of fast storage
• Network drives: 32-128 KB - Avoid network congestion
• Default: 64 KB - Good balance for most scenarios

👥 Max Threads (1-8):
• Single large file: 1-2 threads - Avoid overhead
• Many small files: 4-6 threads - Parallel processing
• Network operations: 1-3 threads - Prevent timeout
• Local SSD: 4-8 threads - Utilize full speed
• Default: 4 threads - Optimal for most systems

⏱ Progress Update (0.1-2.0 seconds):
• Faster updates: 0.1-0.3s - Real-time feedback
• Balanced: 0.5s - Good performance + responsiveness  
• Slower updates: 1.0-2.0s - Better for slow systems""",
            
            "behavior": """🎯 Behavior Settings Help:

📁 File Exists Policy:
• Prompt: Ask user what to do (safest)
• Overwrite: Replace existing files automatically
• Skip: Keep existing files, skip duplicates

🔄 Auto Retry:
• Enabled: Automatically retry failed operations
• Retry Count: How many times to retry (1-10)

✅ Verify Copy:
• Enabled: Check file integrity after copying (slower but safer)
• Disabled: Skip verification (faster but less safe)

🗂 Show Hidden Files:
• Show system and hidden files in explorer

💾 Create Backup:
• Create .bak files before overwriting""",
            
            "appearance": """🎨 Appearance Settings Help:

🌈 Themes:
• Dark Blue: Professional dark theme (best for eyes)
• Dark Green: Nature-inspired dark theme
• Cyberpunk: Futuristic neon theme
• Ocean: Calm blue light theme
• Forest: Natural green theme
• System: Follow your OS theme

🔔 Notifications:
• Sound: Play completion sounds
• Minimize to Tray: Hide to system tray

📊 Visual Features:
• Speed Graph: Show real-time speed charts
• Auto Clear: Remove completed tasks automatically"""
        }
        
        help_window = ctk.CTkToplevel(self.root)
        help_window.title(f"Help - {section.title()}")
        help_window.geometry("600x500")
        help_window.transient(self.root)
        help_window.grab_set()
        
        # Center the window
        help_window.update_idletasks()
        x = (help_window.winfo_screenwidth() // 2) - (600 // 2)
        y = (help_window.winfo_screenheight() // 2) - (500 // 2)
        help_window.geometry(f"600x500+{x}+{y}")
        
        # Help content
        help_frame = ctk.CTkScrollableFrame(help_window)
        help_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        help_text = help_texts.get(section, "No help available for this section.")
        
        ctk.CTkLabel(
            help_frame,
            text=help_text,
            font=ctk.CTkFont(family="B Nazanin", size=12),
            justify="left",
            wraplength=550
        ).pack(pady=10, padx=10, anchor="w")
        
        # Close button
        ctk.CTkButton(
            help_window,
            text="✅ Got it!",
            command=help_window.destroy,
            font=ctk.CTkFont(family="B Nazanin", weight="bold")
        ).pack(pady=10)
    
    def update_buffer_from_slider(self, value):
        """Update buffer size from slider"""
        self.buffer_var.set(str(int(value)))
    
    def update_threads_from_slider(self, value):
        """Update thread count from slider"""
        self.threads_var.set(str(int(value)))
    
    def update_progress_from_slider(self, value):
        """Update progress interval from slider"""
        self.progress_interval_var.set(f"{value:.1f}")
    
    def check_disk_space(self, path: str, required_size: int) -> bool:
        """Check if there's enough disk space"""
        try:
            free_space = psutil.disk_usage(path).free
            # Add 10% buffer to required size
            required_with_buffer = required_size * 1.1
            return free_space > required_with_buffer
        except:
            return True  # If we can't check, assume it's okay
    
    def on_closing(self):
        """Handle application closing"""
        if self.is_copying:
            if messagebox.askyesno("Confirm Exit", "Copy operations are in progress. Exit anyway?"):
                self.cancel_all_tasks()
            else:
                return
        
        # Save current window geometry
        self.settings["window_geometry"] = self.root.geometry()
        
        # Save settings and cleanup
        self.save_settings()
        self.save_cache()
        
        if self.executor:
            self.executor.shutdown(wait=False)
        
        self.root.destroy()

    def on_window_resize(self, event):
        """Handle window resize events for responsive design"""
        if event.widget == self.root:
            try:
                # Get current window size
                window_width = self.root.winfo_width()
                window_height = self.root.winfo_height()
                
                # Only adjust if window is visible and has reasonable size
                if window_width > 100 and window_height > 100:
                    # Adjust column widths based on window size
                    if hasattr(self, 'task_tree'):
                        self.adjust_column_widths(window_width)
                        
            except Exception as e:
                self.logger.error(f"Error handling window resize: {e}")

    def adjust_column_widths(self, window_width):
        """Adjust tree column widths based on window size"""
        try:
            # Calculate available width (minus scrollbar and padding)
            available_width = max(800, window_width - 100)
            
            # Define column weight ratios (flexible sizing)
            column_weights = {
                "File": 0.25,        # 25% - File name
                "Destination": 0.30, # 30% - Destination path  
                "Progress": 0.10,    # 10% - Progress
                "Size": 0.10,        # 10% - Size
                "Copied": 0.10,      # 10% - Copied
                "Speed": 0.10,       # 10% - Speed
                "Status": 0.05       # 5% - Status
            }
            
            # Calculate and set new widths
            for col, weight in column_weights.items():
                new_width = max(60, int(available_width * weight))
                self.task_tree.column(col, width=new_width)
                
        except Exception as e:
            self.logger.error(f"Error adjusting column widths: {e}")

    def add_destination_folder(self):
        """Add a new destination folder"""
        folder = filedialog.askdirectory(title="انتخاب پوشه مقصد")
        if folder and folder not in self.destination_folders:
            self.destination_folders.append(folder)
            self.settings["destination_folders"] = self.destination_folders
            self.save_settings()
            self.update_destination_folders_display()
            self.new_dest_entry.delete(0, 'end')
            self.new_dest_entry.insert(0, folder)

    def remove_destination_folder(self, folder_path):
        """Remove a destination folder"""
        if folder_path in self.destination_folders:
            self.destination_folders.remove(folder_path)
            self.settings["destination_folders"] = self.destination_folders
            self.save_settings()
            self.update_destination_folders_display()

    def update_destination_folders_display(self):
        """Update the display of auto-detected destination folders"""
        try:
            if not hasattr(self, 'dest_folders_frame'):
                return
                
            # Clear existing widgets
            for widget in self.dest_folders_frame.winfo_children():
                widget.destroy()
            
            if not self.destination_folders:
                # Show message when no folders detected
                no_folders_label = ctk.CTkLabel(
                    self.dest_folders_frame,
                    text="🔍 در حال شناسایی درایوها...\n\nاگر درایوی نمایش داده نمی‌شود،\nروی دکمه بروزرسانی مقاصد کلیک کنید",
                    font=ctk.CTkFont(family="B Nazanin", size=12),
                    text_color="gray"
                )
                no_folders_label.pack(pady=50)
                return
            
            # Create drop zones for each auto-detected destination
            for i, dest_info in enumerate(self.destination_folders):
                self.create_auto_destination_zone(dest_info, i)
                
        except Exception as e:
            print(f"Error updating destination display: {e}")

    def create_auto_destination_zone(self, dest_info, index):
        """Create a destination zone for auto-detected folders"""
        try:
            folder_path = dest_info['path']
            folder_name = dest_info['name']
            folder_type = dest_info['type']
            free_space = dest_info.get('free_space', 0)
            
            # Main drop zone frame with different colors for different types
            if folder_type == 'drive':
                border_color = ("blue", "lightblue")
                bg_color = ("#e3f2fd", "#1a237e")
            else:
                border_color = ("green", "lightgreen")
                bg_color = ("#e8f5e8", "#2e7d32")
            
            drop_frame = ctk.CTkFrame(
                self.dest_folders_frame,
                height=100,
                border_width=2,
                border_color=border_color,
                corner_radius=12,
                fg_color=bg_color
            )
            drop_frame.pack(fill="x", padx=5, pady=5)
            drop_frame.pack_propagate(False)
            
            # Main content frame
            content_frame = ctk.CTkFrame(drop_frame, fg_color="transparent")
            content_frame.pack(fill="both", expand=True, padx=10, pady=10)
            
            # Top row: Icon and name
            top_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            top_frame.pack(fill="x")
            
            # Icon based on type
            icon = "💿" if folder_type == 'drive' else "📁"
            icon_label = ctk.CTkLabel(
                top_frame,
                text=icon,
                font=ctk.CTkFont(family="B Nazanin", size=20)
            )
            icon_label.pack(side="left", padx=(0, 10))
            
            # Name and path
            name_label = ctk.CTkLabel(
                top_frame,
                text=folder_name,
                font=ctk.CTkFont(family="B Nazanin", size=14, weight="bold")
            )
            name_label.pack(side="left", anchor="w")
            
            # Bottom row: Path and click instruction
            bottom_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            bottom_frame.pack(fill="x", pady=(5, 0))
            
            path_label = ctk.CTkLabel(
                bottom_frame,
                text=folder_path,
                font=ctk.CTkFont(family="B Nazanin", size=10),
                text_color="gray"
            )
            path_label.pack(side="left", anchor="w")
            
            # Click instruction
            click_label = ctk.CTkLabel(
                bottom_frame,
                text="🎯 کلیک برای کپی فایل‌های انتخابی",
                font=ctk.CTkFont(family="B Nazanin", size=10, weight="bold"),
                text_color=("blue", "lightblue")
            )
            click_label.pack(side="right")
            
            # Enable drag & drop and click functionality
            self.enable_quick_copy_on_widget(drop_frame, folder_path)
            self.enable_quick_copy_on_widget(content_frame, folder_path)
            self.enable_quick_copy_on_widget(name_label, folder_path)
            self.enable_quick_copy_on_widget(path_label, folder_path)
            self.enable_quick_copy_on_widget(click_label, folder_path)
            
        except Exception as e:
            print(f"Error creating destination zone: {e}")

    def enable_quick_copy_on_widget(self, widget, destination_path):
        """Enable quick copy functionality on widget (drag & drop + click)"""
        try:
            # Click functionality - copy selected files from browser
            def on_click(event=None):
                self.quick_copy_selected_files(destination_path)
            
            widget.bind("<Button-1>", on_click)
            
            # Native drag & drop is handled by the NativeDragDrop class
            # No additional setup needed here
            print(f"✓ کلیک سریع فعال شد برای مقصد: {os.path.basename(destination_path)}")
            
        except Exception as e:
            print(f"Error enabling quick copy on widget: {e}")

    def quick_copy_selected_files(self, destination_path):
        """Copy selected files from file browser to destination"""
        try:
            selected_items = self.file_tree.selection()
            if not selected_items:
                messagebox.showinfo("انتخاب فایل", "لطفاً فایل‌هایی را از لیست انتخاب کنید!")
                return
            
            added_count = 0
            for item_id in selected_items:
                values = self.file_tree.item(item_id)['values']
                if len(values) >= 2:
                    file_path = values[1]  # Path column
                    if os.path.exists(file_path):
                        # Add to copy queue and start immediately
                        self.add_task_and_start(file_path, destination_path)
                        added_count += 1
            
            if added_count > 0:
                messagebox.showinfo("کپی آغاز شد", f"{added_count} فایل به صف کپی اضافه شد و کپی آغاز شد!")
            else:
                messagebox.showwarning("خطا", "فایل‌های انتخابی معتبر نیستند!")
                
        except Exception as e:
            print(f"Error in quick copy: {e}")
            messagebox.showerror("خطا", f"خطا در کپی سریع: {e}")

    def add_task_and_start(self, source_path, destination_path):
        """Add a task to the queue and start it immediately"""
        try:
            if not os.path.exists(source_path):
                return
            
            filename = os.path.basename(source_path)
            dest_file = os.path.join(destination_path, filename)
            
            # Check if already exists in queue
            if any(task["source"] == source_path and task["destination"] == dest_file 
                   for task in self.copy_tasks):
                return  # Already in queue
            
            # Create and add task
            task_id = len(self.copy_tasks)
            file_size = self.get_file_size(source_path)
            
            task = {
                "id": task_id,
                "source": source_path,
                "destination": dest_file,
                "filename": filename,
                "size": file_size,
                "copied": 0,
                "progress": 0.0,
                "speed": 0.0,
                "status": "🚀 Auto-Starting",
                "paused": False,
                "cancelled": False,
                "completed": False,
                "start_time": time.time(),
                "last_update": time.time(),
                "retry_count": 0,
                "error_message": "",
                "future": None
            }
            
            self.copy_tasks.append(task)
            
            # Add to task tree
            self.task_tree.insert("", "end", iid=str(task_id), values=(
                filename,
                dest_file,
                "0%",
                self.format_size(file_size),
                "0 B",
                "0.0",
                "🚀 Auto-Starting"
            ))
            
            # Start immediately
            task["status"] = "🔄 Running"
            task["future"] = self.executor.submit(self.copy_task, task)
            self.update_task_display(task)
            
        except Exception as e:
            print(f"Error adding and starting task: {e}")



    def create_drop_zone(self, folder_path, index):
        """Create a drop zone for a destination folder"""
        # Main drop zone frame
        drop_frame = ctk.CTkFrame(
            self.dest_folders_frame,
            height=120,
            border_width=3,
            border_color=("blue", "lightblue"),
            corner_radius=15
        )
        drop_frame.pack(fill="x", padx=10, pady=10)
        drop_frame.pack_propagate(False)
        
        # Folder info frame
        info_frame = ctk.CTkFrame(drop_frame, fg_color="transparent")
        info_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Folder name and path
        folder_name = os.path.basename(folder_path) or folder_path
        name_label = ctk.CTkLabel(
            info_frame,
            text=f"📁 {folder_name}",
            font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold")
        )
        name_label.pack(anchor="w")
        
        path_label = ctk.CTkLabel(
            info_frame,
            text=folder_path,
            font=ctk.CTkFont(family="B Nazanin", size=12),
            text_color="gray"
        )
        path_label.pack(anchor="w", pady=(0, 10))
        
        # Controls frame
        controls_frame = ctk.CTkFrame(info_frame, fg_color="transparent")
        controls_frame.pack(fill="x")
        
        # Click instruction
        click_label = ctk.CTkLabel(
            controls_frame,
            text="🎯 فایل بکشید اینجا یا کلیک کنید",
            font=ctk.CTkFont(family="B Nazanin", size=12, weight="bold"),
            text_color=("blue", "lightblue")
        )
        click_label.pack(side="left")
        
        # Remove button
        remove_btn = ctk.CTkButton(
            controls_frame,
            text="🗑️",
            width=30,
            height=30,
            command=lambda: self.remove_destination_folder(folder_path),
            fg_color="red",
            hover_color="darkred"
        )
        remove_btn.pack(side="right")
        
        # Enable drag & drop on all elements of the drop zone
        self.enable_drop_on_widget(drop_frame, folder_path)
        self.enable_drop_on_widget(info_frame, folder_path) 
        self.enable_drop_on_widget(name_label, folder_path)
        self.enable_drop_on_widget(path_label, folder_path)
        self.enable_drop_on_widget(click_label, folder_path)

    def enable_drop_on_widget(self, widget, destination_path):
        """فعال کردن قابلیت کلیک روی ویجت برای انتخاب فایل"""
        # Native drag and drop is handled by the NativeDragDrop class on file tree
        # Here we just enable click functionality for manual file selection
        self.setup_manual_file_selection(widget, destination_path)
        print(f"✓ کلیک برای انتخاب فعال شد برای: {os.path.basename(destination_path)}")
    
    
    def on_drag_enter(self, widget):
        """Visual feedback when dragging over drop zone"""
        try:
            widget.configure(fg_color=("#c8e6c9", "#2e7d32"))  # Light green highlight
            widget.configure(border_color="#4caf50", border_width=3)
            print("🎯 Drag entered drop zone")
        except:
            pass
    
    def on_drag_leave(self, widget):
        """Reset visual feedback when leaving drop zone"""
        try:
            widget.configure(fg_color=("#f5f5f5", "#424242"))  # Reset to default
            widget.configure(border_color=("gray70", "gray25"), border_width=2)
            print("↩ Drag left drop zone")
        except:
            pass

    def setup_manual_file_selection(self, widget, destination_path):
        """Setup manual file selection"""
        def manual_select(event=None):
            # Create a simple dialog to choose between files or folders
            choice_window = ctk.CTkToplevel(self.root)
            choice_window.title("انتخاب نوع فایل")
            choice_window.geometry("300x200")
            choice_window.transient(self.root)
            choice_window.grab_set()
            
            # Center the window
            choice_window.update_idletasks()
            x = (choice_window.winfo_screenwidth() // 2) - (300 // 2)
            y = (choice_window.winfo_screenheight() // 2) - (200 // 2)
            choice_window.geometry(f"300x200+{x}+{y}")
            
            ctk.CTkLabel(
                choice_window,
                text="چه چیزی می‌خواهید کپی کنید؟",
                font=ctk.CTkFont(family="B Nazanin", size=16, weight="bold")
            ).pack(pady=20)
            
            def select_files():
                choice_window.destroy()
                files = filedialog.askopenfilenames(title="انتخاب فایل‌ها برای کپی")
                if files:
                    self.handle_dropped_files(files, destination_path)
            
            def select_folders():
                choice_window.destroy()
                folders = []
                while True:
                    folder = filedialog.askdirectory(title="انتخاب پوشه برای کپی (Cancel برای پایان)")
                    if folder:
                        folders.append(folder)
                        if not messagebox.askyesno("ادامه", "آیا می‌خواهید پوشه دیگری نیز اضافه کنید؟"):
                            break
                    else:
                        break
                if folders:
                    self.handle_dropped_files(folders, destination_path)
            
            ctk.CTkButton(
                choice_window,
                text="📄 انتخاب فایل‌ها",
                command=select_files,
                width=200,
                height=40
            ).pack(pady=10)
            
            ctk.CTkButton(
                choice_window,
                text="📁 انتخاب پوشه‌ها",
                command=select_folders,
                width=200,
                height=40
            ).pack(pady=10)
        
        widget.bind("<Button-1>", manual_select)

    def handle_dropped_files(self, files, destination_path):
        """Handle files dropped on a destination folder"""
        try:
            valid_files = []
            for file_path in files:
                if os.path.exists(file_path):
                    valid_files.append(file_path)
            
            if not valid_files:
                messagebox.showwarning("خطا", "فایل‌های انتخابی معتبر نیستند!")
                return
            
            # Add files to copy queue and start immediately
            added_count = 0
            for file_path in valid_files:
                if os.path.isfile(file_path):
                    filename = os.path.basename(file_path)
                    dest_file = os.path.join(destination_path, filename)
                    
                    # Check if already exists
                    if any(task["source"] == file_path and task["destination"] == dest_file 
                           for task in self.copy_tasks):
                        continue
                    
                    # Add to queue
                    file_size = self.get_file_size(file_path)
                    task_id = len(self.copy_tasks)
                    
                    task = {
                        "id": task_id,
                        "source": file_path,
                        "destination": dest_file,
                        "filename": filename,
                        "size": file_size,
                        "copied": 0,
                        "progress": 0.0,
                        "speed": 0.0,
                        "status": "🚀 Auto-Starting",
                        "paused": False,
                        "cancelled": False,
                        "completed": False,
                        "start_time": time.time(),
                        "last_update": time.time(),
                        "retry_count": 0,
                        "error_message": "",
                        "future": None
                    }
                    
                    self.copy_tasks.append(task)
                    
                    # Add to tree display
                    self.task_tree.insert("", "end", iid=str(task_id), values=(
                        filename,
                        dest_file,
                        "0%",
                        self.format_size(file_size),
                        "0 B",
                        "0.0",
                        "🚀 Auto-Starting"
                    ))
                    
                    # Start immediately
                    task["status"] = "🔄 Running"
                    task["future"] = self.executor.submit(self.copy_task, task)
                    self.update_task_display(task)
                    added_count += 1
                    
                elif os.path.isdir(file_path):
                    # Handle directories
                    dirname = os.path.basename(file_path)
                    dest_dir = os.path.join(destination_path, dirname)
                    
                    # Check if already exists
                    if any(task["source"] == file_path and task["destination"] == dest_dir 
                           for task in self.copy_tasks):
                        continue
                    
                    # Calculate directory size
                    dir_size = self.get_directory_size(file_path)
                    task_id = len(self.copy_tasks)
                    
                    task = {
                        "id": task_id,
                        "source": file_path,
                        "destination": dest_dir,
                        "filename": dirname,
                        "size": dir_size,
                        "copied": 0,
                        "progress": 0.0,
                        "speed": 0.0,
                        "status": "🚀 Auto-Starting",
                        "paused": False,
                        "cancelled": False,
                        "completed": False,
                        "start_time": time.time(),
                        "last_update": time.time(),
                        "retry_count": 0,
                        "error_message": "",
                        "future": None
                    }
                    
                    self.copy_tasks.append(task)
                    
                    # Add to tree display
                    self.task_tree.insert("", "end", iid=str(task_id), values=(
                        dirname,
                        dest_dir,
                        "0%",
                        self.format_size(dir_size),
                        "0 B",
                        "0.0",
                        "🚀 Auto-Starting"
                    ))
                    
                    # Start immediately
                    task["status"] = "🔄 Running"
                    task["future"] = self.executor.submit(self.copy_task, task)
                    self.update_task_display(task)
                    added_count += 1
            
            self.update_overall_progress()
            
            # Switch to tasks tab to show progress
            self.notebook.select(1)  # Tasks tab
            
            if added_count > 0:
                self.update_status(f"🚀 شروع خودکار: {added_count} فایل/پوشه")
                messagebox.showinfo("شروع کپی", f"{added_count} فایل/پوشه به صورت خودکار شروع به کپی شدند!")
            else:
                messagebox.showinfo("هشدار", "همه فایل‌ها قبلاً در صف کپی موجود هستند!")
                
        except Exception as e:
            self.logger.error(f"Error handling dropped files: {e}")
            messagebox.showerror("خطا", f"خطا در پردازش فایل‌ها: {str(e)}")

    def get_directory_size(self, directory_path):
        """Calculate total size of a directory"""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(directory_path):
                for filename in filenames:
                    file_path = os.path.join(dirpath, filename)
                    if os.path.exists(file_path):
                        total_size += os.path.getsize(file_path)
        except Exception as e:
            self.logger.warning(f"Error calculating directory size: {e}")
        return total_size
 
    def run(self):
        """Run the application"""
        try:
            # Handle command line arguments for context menu integration
            if len(sys.argv) > 1:
                if sys.argv[1] == "copy" and len(sys.argv) > 2:
                    # Add file to clipboard (for future implementation)
                    pass
                elif sys.argv[1] == "paste" and len(sys.argv) > 2:
                    # Set destination and paste (for future implementation)
                    if hasattr(self, 'dest_entry') and self.dest_entry:
                        self.dest_entry.insert(0, sys.argv[2])
            
            # Restore window geometry
            if "window_geometry" in self.settings:
                self.root.geometry(self.settings["window_geometry"])
            
            self.root.mainloop()
            
        except Exception as e:
            self.logger.error(f"Application error: {e}")
            messagebox.showerror("Application Error", f"An unexpected error occurred: {e}")

def main():
    """Main entry point"""
    try:
        # Always use CTk for consistent styling, enable DnD within the app
        root = ctk.CTk()
        
        # Native drag and drop support is built-in
        print("✓ سیستم درگ اند دراپ بومی فعال شد")
        
        app = FileCopierApp(root)
        app.run()
    except Exception as e:
        print(f"Failed to start application: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()