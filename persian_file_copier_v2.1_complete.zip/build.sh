#!/bin/bash
echo "Building Persian File Copier Pro executable..."
python3 build_exe.py